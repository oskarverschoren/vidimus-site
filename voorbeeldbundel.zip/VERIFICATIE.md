# Vidimus — verificatiehandleiding voor deskundigen

**Specificatie v1.3 · 28 september 2026** (v1.3: vertrouwelijke stromen, de sleutel van de inhoud alleen bij het bedrijf, stap 9; v1.2: persoonsgegevens met een geheim zout per registratie en gewone SHA-256, canon `vidimus-json-3`, stap 1; v1.1: gekwalificeerde tijdstempel boven de batch, stap 4b, en Evidence Record voor officiële validatiesoftware, stap 8; alles uit eerdere versies blijft ongewijzigd geldig). Dit document is de vaste beschrijving van de bewijsketen: canonieke JSON en veldvolgorde, een geheim zout per registratie voor persoonsgegevens (vroeger HMAC-SHA-256 met een salt per stroom), hashketen in het grootboek (prev), Merkle-regels (oneven blad wordt gedupliceerd), ankerinterval van 5 minuten, RFC 3161-tijdstempel en OpenTimestamps. Wijzigingen krijgen een nieuw versienummer; oude bundels blijven onder hun eigen versie na te rekenen.

Voor wie een bewijsbundel van Vidimus moet narekenen zonder Vidimus te vertrouwen: gerechtsdeskundige, auditor, advocaat, IT-dienst van een tegenpartij. Alles hieronder werkt zonder account en zonder Vidimus-software; alleen de bundel (.zip) is nodig. Stappen 1 tot 4, 6 en 7 werken offline. Stap 5 (Bitcoin) vraagt één opzoeking in een publieke blockexplorer, of een eigen Bitcoin-node.

## 1. Wat in de bundel zit

| Bestand | Inhoud |
|---|---|
| `manifest.json` | alle feiten en tussenwaarden: vingerafdruk, Merkle-pad en -wortel, batch, handtekeningen, tijdstempel, grootboekrecord, Bitcoin-status |
| `manifest.sig` | Ed25519-handtekening van Vidimus over de exacte bytes van `manifest.json` |
| `registration.json` | de originele inhoud van de registratie in canonieke vorm (ontbreekt als de inhoud na de bewaartermijn gewist is) |
| `attachments/…` | de originele bijlagen: foto's, pdf's, cmr, metingen (idem) |
| `signer-cert.pem`, `org-ca.pem` | certificaat van de indiener en de organisatie die het uitgaf |
| `platform-cert.pem` | certificaat van Vidimus (voor `manifest.sig`) |
| `tijdstempel` (in manifest, `tsa.token_b64`) | RFC 3161-token van Sectigo over de Merkle-wortel |
| `gekwalificeerd.tsr` | (vanaf 27/09/2026, zodra aanwezig) gekwalificeerde tijdstempel (eIDAS, RFC 3161) over de gekwalificeerde wortel; pad en wortel in `manifest.qualified` |
| `bewijs.ers` | Evidence Record (RFC 4998): de hele keten van vingerafdruk tot tijdstempel in één standaardbestand, voor de validatietool van de Europese Commissie of het BSI (stap 8) |
| `vingerafdruk-invoer.json` | de exacte bytes die gehasht zijn (SHA-256 = de vingerafdruk); het "originele document" bij stap 8. Ontbreekt alleen bij gewiste inhoud en bij registraties met persoonsgegevens van vóór 28/09/2026 (HMAC) |
| `bitcoin.ots` | OpenTimestamps-bewijs: wortel → Bitcoin-blok |
| `sleutels.json` | (alleen vertrouwelijke stroom) per bijlage de bestandssleutel, vergrendeld met de publieke bedrijfssleutel; de bijlagen zelf zijn dan cijfertekst (stap 9) |
| `verify_bundle.py` | referentiescript dat alle controles uitvoert |

## 2. Snel: één commando

```
pip install cryptography rfc3161ng opentimestamps-client   # eenmalig; zonder de laatste twee blijven tijdstempel en Bitcoin op null
python3 verify_bundle.py bundel.zip
```

Uitkomst per controle: `true` (klopt), `false` (klopt niet), `null` (niet controleerbaar in deze omgeving, met reden in `notes`). `"ok": true` betekent: geen enkele controle faalde. Onderaan telt het script hoeveel controles het echt heeft nagerekend en hoeveel niet (null). Een null is geen bevestiging: installeer wat in `notes` staat, of reken die stap met de hand na.

## 3. Met de hand, stap voor stap

Wie het script niet vertrouwt, doet hetzelfde met standaardgereedschap. Alle verwachte waarden staan in `manifest.json`.

**Stap 1 — Inhoud (wat).**
`registration.json` is de canonieke JSON (sleutels gesorteerd, geen witruimte, UTF-8). Bereken per bijlage `sha256sum attachments/<naam>`. Bouw het object `{"canon": "vidimus-json-2", "org": "<organisatiekenmerk>", "payload": <registration.json>, "attachments": {<naam>: <sha256>, …}}`, canoniek geserialiseerd, en neem daar SHA-256 van. Resultaat = `registration.hash` in het manifest. Het organisatiekenmerk staat in het manifest onder `registration.org_kenmerk` (en onder `organisatie.kenmerk`, en als serialNumber in `signer-cert.pem`): zo is elke vingerafdruk aan één geïdentificeerde onderneming gebonden. Registraties van vóór 26 september 2026 dragen `"canon": "vidimus-json-1"` en hebben geen `org`-veld in de hash-invoer; het script kent beide.
Bijlagen tellen op **naam**, gesorteerd; de volgorde van uploaden speelt geen rol.

**Persoonsgegevens.** Sinds 28 september 2026 dragen registraties uit stromen met persoonsgegevens `"canon": "vidimus-json-3"`. Het object krijgt dan een vijfde veld, `"salt": "<disclosure.salt>"`: het geheime zout van deze ene registratie, zodat niemand namen of nummers kan raden door zelf te hashen. Daarover neemt u gewone SHA-256, net als hierboven. Het kant-en-klare object staat in de bundel als `vingerafdruk-invoer.json`: `sha256sum vingerafdruk-invoer.json` = `registration.hash`. Het zout zegt niets over andere registraties. Oudere registraties uit zulke stromen (`"hash_type": "hmac-sha256"`) gebruiken HMAC-SHA256 met de salt uit `disclosure.salt` als sleutel, over het object zonder `salt`-veld; het script kent beide.

**Hele map in één registratie.** Is de bijlage `attachments/manifest.json` een map-manifest (`"type": "vidimus-manifest"`), dan staan de bestanden zelf niet in de bundel: ze zijn nooit geüpload. Het manifest noemt per bestand het pad en de SHA-256. Eén bestand nakijken: `sha256sum <bestand>` en die waarde opzoeken in het manifest; het manifest zelf hangt via stap 1 aan de registratie (`sha256sum attachments/manifest.json` = de waarde onder `attachments` én `document_sha256` in `registration.json`). Een hele map in één keer: `python3 vidimus-map.py controleer attachments/manifest.json <map>` (script op `/tools/vidimus-map.py`, werkt offline).

**Vastgelegde webpagina.** Bij een registratie met `"type": "webcapture"` zijn de bijlagen `pagina.html` (de HTML zoals de server van Vidimus ze ontving), `headers.json` (verzoek, omleidingen, antwoordheaders, TLS-certificaat van de site) en, als er een browser was, `schermbeeld.png` en `dom.html`. `sha256sum attachments/pagina.html` = `document_sha256` in `registration.json`. Open `pagina.html` niet zomaar in een browser met toegang tot uw netwerk: het is inhoud van een derde. De registratie toont wat op dat adres aan onze server werd aangeboden op dat moment; ze zegt niets over wat een andere bezoeker te zien kreeg.

**Stap 2 — Batch (Merkle).**
Neem de vingerafdruk uit stap 1 en loop het pad `merkle.path` af: op elke stap de twee waarden sorteren, aan elkaar plakken (als bytes) en SHA-256 nemen. Eindresultaat = `merkle.root`.

**Stap 3 — Wie (handtekening indiener).**
`registration.signature_b64` is een Ed25519-handtekening over de bytes van de vingerafdruk (hex gedecodeerd), te controleren met de publieke sleutel in `signer-cert.pem`. Controleer dat dit certificaat is uitgegeven door `org-ca.pem`. Met gewone openssl: `openssl x509 -in signer-cert.pem -pubkey -noout > indiener.pub`, zet de vingerafdruk als bytes in `hash.bin` en `signature_b64` gedecodeerd in `sig.bin`, dan `openssl pkeyutl -verify -pubin -inkey indiener.pub -rawin -in hash.bin -sigfile sig.bin`, en `openssl verify -CAfile org-ca.pem signer-cert.pem`.
`signer.key_custody = "device"` betekent: de privésleutel stond op het toestel van de indiener, niet bij Vidimus. `"platform-held"` betekent: een systeemsleutel van de organisatie (koppeling, poort, sensor) die Vidimus bewaart; de handtekening toont dan welk systeem van welke organisatie indiende, niet welke persoon.
`signer.mandaat` verwijst naar twee eerdere, zelf verankerde registraties in de stroom 'akkoorden' van de organisatie: `werkgever` (de beheerder verklaarde bij het uitnodigen wie de persoon is en dat hij mag tekenen, met naam, e-mail, IP en tijdstip) en `toestelakkoord` (de persoon tekende bij het koppelen, met dezelfde sleutel, de verklaring dat het toestel van hem is; de verklaringstekst, haar SHA-256 en de handtekening staan in die registratie). Beide zijn op te vragen bij de eigenaar en met dezelfde stappen na te rekenen; `met_verklaring_persoon = true` betekent dat de tweede verklaring door de persoon zelf is getekend.
`organisatie` zegt wie de organisatie is (naam, ondernemingsnummer) en hoe haar identiteit vaststaat: `mandaat_eid` verwijst naar een registratie waarin de beheerder een mandaat-pdf met zijn Belgische eID tekende (PAdES, gekwalificeerde handtekening; naam en certificaat in die registratie, de getekende pdf bij de eigenaar). Ontbreekt dat, dan staat er eerlijk: "verklaring van bevoegdheid, niet onafhankelijk geverifieerd".

**Stap 4 — Wanneer, getuige 1 (Sectigo).**
Sla `tsa.token_b64` op als `tijdstempel.tsr` (base64 gedecodeerd) en controleer:
```
openssl ts -reply -token_in -in tijdstempel.tsr -text      # 'Message data' moet gelijk zijn aan merkle.root; 'Time stamp' is het tijdstip
openssl cms -verify -inform DER -in tijdstempel.tsr -purpose timestampsign -out /dev/null -CAfile <rootcertificaten van uw systeem>
```
Het tweede commando controleert de handtekening van Sectigo en de keten (Signer → CA R41 → Root R46 → USERTrust RSA) tot een rootcertificaat dat al op uw computer staat, niet van ons. Uitkomst: `Verification successful`. Rootcertificaten: op Linux `/etc/ssl/certs/ca-certificates.crt`; op macOS `security find-certificate -a -p /System/Library/Keychains/SystemRootCertificates.keychain > roots.pem`.
Let op: `openssl ts -verify` geeft bij deze Sectigo-tokens in OpenSSL 3 de fout `ess cert id not found`, ook als het token in orde is. Gebruik daarom `cms -verify` samen met de vergelijking van 'Message data'.

**Stap 4b — Wanneer, gekwalificeerd (eIDAS).**
Staat er `qualified` in het manifest, dan kreeg de batch daarna een gekwalificeerde tijdstempel van een erkende vertrouwensdienst. Om de zes uur (bij een druk jaar hoogstens om de twaalf uur) worden alle nieuwe batchwortels samen in één Merkle-boom gezet (zelfde regels als stap 2) en krijgt de wortel daarvan één gekwalificeerd stempel.
1. `qualified.batch_root` moet gelijk zijn aan `merkle.root`.
2. Loop `qualified.path` af vanaf `merkle.root`, zoals in stap 2: het resultaat moet `qualified.root` zijn.
3. Controleer het token:
```
openssl ts -reply -token_in -in gekwalificeerd.tsr -text      # 'Message data' = qualified.root; 'Time stamp' = het gekwalificeerde tijdstip
```
4. Zoek de uitgever (TSA-naam in de uitvoer) op in de EU-vertrouwenslijst (https://eidas.ec.europa.eu/efda/tl-browser/): een gekwalificeerde tijdstempeldienst staat daar als "QTST" met status "granted". Het certificaat van de uitgever staat mee in het token; de rootcertificaten van EU-vertrouwensdiensten staan vaak níét in de standaard-trust-store van uw computer, maar wel in de vertrouwenslijst zelf.
Het wettelijk vermoeden (eIDAS art. 41 lid 2) geldt voor het tijdstip van het gekwalificeerde stempel. Het precieze moment van registratie komt van stap 4; de gekwalificeerde tijdstempel bevestigt het binnen zes uur, bij een druk jaar binnen twaalf uur.

**Stap 5 — Wanneer, getuige 2 (Bitcoin).**
```
pip install opentimestamps-client
ots info bitcoin.ots                                        # pad van de wortel naar het blok
ots --no-bitcoin verify -d <merkle.root> bitcoin.ots        # toont: "check that Bitcoin block <hoogte> has merkleroot <waarde>"
```
Zoek dat blok op in een publieke blockexplorer (bv. blockstream.info of mempool.space) en vergelijk de merkle-wortel. Gelijk = de wortel bestond vóór het tijdstip van dat blok. Met een eigen Bitcoin-node doet `ots verify -d <merkle.root> bitcoin.ots` alles in één stap. Zonder `block_height` in `manifest.bitcoin` is er nog geen blok; download de bundel dan later opnieuw.
Bitcoin bewijst alleen "vóór dit blok". Het precieze tijdstip komt van het tijdstempel in stap 4; bij oudere registraties kan het Bitcoin-blok dagen of weken later liggen.

**Stap 6 — Grootboek.**
`ledger.record` bevat `index`, `prev`, `time` en `record`. SHA-256 over de canonieke JSON van die vier velden = `ledger.tx_id`, en `record.root` = `merkle.root`. `prev` verwijst naar het vorige record: één record wijzigen breekt de keten.

**Stap 7 — Handtekening Vidimus.**
`manifest.sig` is een Ed25519-handtekening (64 bytes, ruw) over de exacte bytes van `manifest.json`, te controleren met `platform-cert.pem`: `openssl x509 -in platform-cert.pem -pubkey -noout > vidimus.pub` en `openssl pkeyutl -verify -pubin -inkey vidimus.pub -rawin -in manifest.json -sigfile manifest.sig`. Wijzigt iemand het manifest, dan faalt dit.

**Stap 8 — Zonder Vidimus, met officiële software (Evidence Record).**
`bewijs.ers` is een Evidence Record volgens RFC 4998: de internationale standaard voor "dit gegeven bestond op tijdstip T en is sindsdien niet gewijzigd". Het bevat de hashlijsten van de vingerafdruk tot de getijdstempelde wortel (stap 2 en 4b) en het tijdstempeltoken zelf. Zo controleert u het met software van de Europese Commissie of het Duitse BSI, niet van ons.

*A. Validatiesoftware van de Europese Commissie (DSS), online demo* — https://ec.europa.eu/digital-building-blocks/DSS/webapp-demo/validation (volgens de Commissie bedoeld om te testen; voor een zaak: B)
1. Bij **Signed file**: kies `bewijs.ers`.
2. Bij **Original file(s)**: kies `vingerafdruk-invoer.json`. Is de inhoud gevoelig, kies dan dat alleen de digest (SHA-256) verstuurd wordt: dan verlaat alleen de vingerafdruk uw computer.
3. **Validation level**: *Validation with archival data*. Beleid: het standaardbeleid.
4. Valideer. Bij het Evidence Record staat "Indication: PASSED" en de "POE time" (tijdstip waarop het bestaan bewezen is). In het detailrapport: "Time-stamp Qualification: QTSA" en "Does first hash value list contain only data objects provided to the validation?" PASSED.
   Getest op 27/09/2026 met DSS 6.5 op een registratie van Vidimus zelf: PASSED, QTSA (GLOBALTRUST). "Maximum validity time" is de einddatum van het certificaat van de tijdstempeldienst; vóór die datum verlengt Vidimus het Evidence Record met een nieuwe archieftijdstempel (RFC 4998 §5.2).

*B. Dezelfde tool op uw eigen computer* — https://ec.europa.eu/digital-building-blocks/DSS/webapp-demo/signature-standalone
Download de standalone toepassing of de demobundel, start ze lokaal (http://localhost:8080) en volg dezelfde stappen. Uw bestanden verlaten uw computer niet; alleen de EU-vertrouwenslijst wordt opgehaald.

*C. ER Verify Tool van het BSI (TR-ESOR)* — https://github.com/de-bund-bsi-tr-esor/ERVerifyTool
Voor deskundigen: Java 11, bouwen met Gradle, een ingestelde online tijdstempelcontrole in `config.xml`. Daarna:
```
./checktool -conf ../../config/config.xml -data vingerafdruk-invoer.json -er bewijs.ers
```
Uitkomst: een XML-verificatierapport volgens TR-ESOR-ERS 1.3.

*D. Wie de onderneming is (eID-mandaat), met dezelfde EU-software.*
Staat in het manifest `organisatie.mandaat_eid`, dan heeft de beheerder de organisatie geïdentificeerd met een mandaat dat hij met zijn Belgische eID tekende. Het getekende pdf zit niet in de bundel: het eID-certificaat bevat zijn rijksregisternummer. Vraag het aan de onderneming (in de app: Instellingen › Mandaat › Getekend mandaat downloaden).
1. `sha256sum mandaat.pdf` moet gelijk zijn aan `organisatie.mandaat_eid.pdf_sha256`; die waarde is zelf verankerd in registratie `organisatie.mandaat_eid.registratie`.
2. Open het pdf in de validatiesoftware van de Europese Commissie (zelfde adres als hierboven, bij "Signed file", zonder origineel). Verwacht: de handtekening is gekwalificeerd (QES), met een certificaat van de Belgische eID.
Zo is ook de schakel onderneming → beheerder met officiële software te controleren. De schakel beheerder → toestel of systeem → registratie loopt via stap 3.

Wat stap 8 wél en niet dekt. Wel: dat precies deze inhoud (met de SHA-256 van elke bijlage erin) bestond op het tijdstip van de tijdstempel en sindsdien ongewijzigd is. De bijlagen zelf koppelt u eraan met `sha256sum attachments/<naam>`: die waarde staat in `vingerafdruk-invoer.json`. Niet: wie tekende (stap 3) en de Bitcoin-verankering (stap 5); die staan buiten het Evidence Record. Bij registraties met persoonsgegevens van vóór 28 september 2026 is de vingerafdruk een HMAC met een geheime salt; daar ontbreekt `vingerafdruk-invoer.json` en werkt de browserroute niet. Het Evidence Record blijft dan na te rekenen met de DSS-bibliotheek, met de vingerafdruk als digest, of met stap 1 tot 7. Sinds 28 september werkt de route ook bij persoonsgegevens (zie stap 1).

**Stap 9 — Vertrouwelijke stroom: de inhoud openen (alleen het bedrijf).**
Staat er `vertrouwelijk` in het manifest, dan zijn de bijlagen op het toestel versleuteld (AES-256-GCM) en is elke bestandssleutel vergrendeld met de publieke bedrijfssleutel (RSA-OAEP, SHA-256, 3072 bit). Vidimus heeft de private sleutel nooit gehad. De vingerafdrukken in het manifest zijn die van de originelen: stap 1 tot 8 werken dus gewoon, ook zonder de inhoud te openen. Wie de inhoud zelf wil zien, heeft het herstelbestand van het bedrijf en de wachtzin nodig:

```
python3 verify_bundle.py bundel.zip --herstel herstelsleutel.json --naar ontsleuteld
```

Het script vraagt de wachtzin, ontgrendelt elke bestandssleutel uit `sleutels.json`, ontsleutelt de bijlage en meldt per bestand of het origineel exact de verankerde vingerafdruk heeft. De inhoud van de velden zit in de bijlage `inhoud.json`. Het herstelbestand is JSON: de private sleutel (PKCS#8) versleuteld met AES-256-GCM onder een sleutel afgeleid van de wachtzin (PBKDF2-SHA256, 600.000 rondes, zout en iv in het bestand); met die gegevens is het ook met andere software te openen.

## 4. Wat een afwijking betekent

| Controle faalt | Betekenis |
|---|---|
| inhoud (stap 1) | een bestand of veld is niet meer wat er verankerd is; het script noemt de bijlage |
| Merkle (stap 2) | de vingerafdruk zit niet in deze batch |
| handtekening indiener | niet getekend met de sleutel van deze indiener |
| tijdstempel / Bitcoin | de wortel bestond niet vóór dat tijdstip, of het token hoort bij een andere wortel |
| handtekening Vidimus | het manifest is achteraf gewijzigd |

Een gewijzigde inhoud laat alle andere controles intact. Zo blijkt niet alleen dát er iets veranderd is, maar ook wat.

## 5. Grenzen, eerlijk

- Vidimus bewijst dat een inhoud bestond op een tijdstip en met welke sleutel ze getekend werd. Niet dat de inhoud waar is: een foute temperatuur blijft een foute temperatuur, maar wel verankerd als "dit is wat toen gemeld werd".
- Een correctie is nooit een wijziging maar een nieuwe registratie met eigen hash en tijdstip. Beide versies blijven bestaan.
- Is de inhoud gewist na de bewaartermijn, dan bewijst de bundel nog dát iets bestond, wie tekende en wanneer, niet wát.
- Zonder `disclosure.salt` is de inhoud van een registratie met persoonsgegevens niet herrekenbaar; de rest van de keten wel.
- Bij een vertrouwelijke stroom kan alleen wie het herstelbestand en de wachtzin heeft de inhoud openen. Verliest het bedrijf beide, dan blijft het bewijs dát er iets was en wanneer, maar kan niemand de inhoud nog lezen, ook Vidimus niet.

Vidimus · VO Initiatives BV · vidimus.be/verificatie.html · oskar@vo-initiatives.com

## Hoe sterk is de handtekening van de persoon?
`manifest.signer.bevestiging` zegt hoe de persoon tekende: `{"via":"passkey","biometrie":true}` betekent dat het toestel een Face ID- of vingerafdrukcontrole (WebAuthn, vlag *user verified*) eiste vóór de toestelsleutel mocht tekenen; `{"via":"enclave","biometrie":true}` is de iOS-app: een P-256-sleutel in de Secure Enclave die pas tekent na Face ID of pincode (ES256 over de registratie-hash, publieke sleutel bij de indiener); `{"via":"toestel"}` is een toestelsleutel zonder biometrie; `"reden":"offline-wachtrij"` betekent dat de bevestiging zonder verbinding werd gezet en later gesynchroniseerd. Ontbreekt het veld, dan is de registratie ouder dan 10 september 2026. De toestelsleutel zelf bewijst het toestel, niet de persoon: wie het toestel kreeg staat in de verklaring werkgever (`signer.mandaat`), en de organisatie daarachter in `organisatie.kenmerk`.
