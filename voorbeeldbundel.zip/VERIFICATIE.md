# Vidimus — verificatiehandleiding voor deskundigen

**Specificatie v1.0 · 12 september 2026.** Dit document is de vaste beschrijving van de bewijsketen: canonieke JSON en veldvolgorde, HMAC-SHA-256 met een salt per stroom voor persoonsgegevens, hashketen in het grootboek (prev), Merkle-regels (oneven blad wordt gedupliceerd), ankerinterval van 5 minuten, RFC 3161-tijdstempel en OpenTimestamps. Wijzigingen krijgen een nieuw versienummer; oude bundels blijven onder hun eigen versie na te rekenen.

Voor wie een bewijsbundel van Vidimus moet narekenen zonder Vidimus te vertrouwen: gerechtsdeskundige, auditor, advocaat, IT-dienst van een tegenpartij. Alles hieronder werkt zonder account, zonder netwerk en zonder Vidimus-software; alleen de bundel (.zip) is nodig.

## 1. Wat in de bundel zit

| Bestand | Inhoud |
|---|---|
| `manifest.json` | alle feiten en tussenwaarden: vingerafdruk, Merkle-pad en -wortel, batch, handtekeningen, tijdstempel, grootboekrecord, Bitcoin-status |
| `manifest.sig` | Ed25519-handtekening van Vidimus over de exacte bytes van `manifest.json` |
| `registration.json` | de originele inhoud van de registratie in canonieke vorm (ontbreekt als de inhoud na de bewaartermijn gewist is) |
| `attachments/…` | de originele bijlagen: foto's, pdf's, cmr, metingen (idem) |
| `signer-cert.pem`, `org-ca.pem` | certificaat van de indiener en de organisatie die het uitgaf |
| `platform-cert.pem` | certificaat van Vidimus (voor `manifest.sig`) |
| `tijdstempel` (in manifest, `tsa.token_b64`) | RFC 3161-token van Sectigo over de Merkle-wortel |
| `bitcoin.ots` | OpenTimestamps-bewijs: wortel → Bitcoin-blok |
| `verify_bundle.py` | referentiescript dat alle controles uitvoert |

## 2. Snel: één commando

```
pip install cryptography rfc3161ng        # eenmalig
python3 verify_bundle.py bundel.zip
```

Uitkomst per controle: `true` (klopt), `false` (klopt niet), `null` (niet controleerbaar in deze omgeving, met reden in `notes`). `"ok": true` betekent: inhoud, Merkle-pad, handtekening indiener, handtekening Vidimus en grootboek kloppen, en tijdstempel en Bitcoin spreken dat niet tegen.

## 3. Met de hand, stap voor stap

Wie het script niet vertrouwt, doet hetzelfde met standaardgereedschap. Alle verwachte waarden staan in `manifest.json`.

**Stap 1 — Inhoud (wat).**
`registration.json` is de canonieke JSON (sleutels gesorteerd, geen witruimte, UTF-8). Bereken per bijlage `sha256sum attachments/<naam>`. Bouw het object `{"canon": "vidimus-json-1", "payload": <registration.json>, "attachments": {<naam>: <sha256>, …}}`, canoniek geserialiseerd, en neem daar SHA-256 van. Resultaat = `registration.hash` in het manifest.
Bijlagen tellen op **naam**, gesorteerd; de volgorde van uploaden speelt geen rol. Bij stromen met persoonsgegevens is de hash HMAC-SHA256 met de salt uit `disclosure.salt` (alleen in de bundel van de eigenaar).

**Stap 2 — Batch (Merkle).**
Neem de vingerafdruk uit stap 1 en loop het pad `merkle.path` af: op elke stap de twee waarden sorteren, aan elkaar plakken (als bytes) en SHA-256 nemen. Eindresultaat = `merkle.root`.

**Stap 3 — Wie (handtekening indiener).**
`registration.signature_b64` is een Ed25519-handtekening over de bytes van de vingerafdruk (hex gedecodeerd), te controleren met de publieke sleutel in `signer-cert.pem`. Controleer dat dit certificaat is uitgegeven door `org-ca.pem`. `signer.key_custody = "device"` betekent: de privésleutel stond op het toestel van de indiener, niet bij Vidimus.
`signer.mandaat` verwijst naar twee eerdere, zelf verankerde registraties in de stroom 'akkoorden' van de organisatie: `werkgever` (de beheerder verklaarde bij het uitnodigen wie de persoon is en dat hij mag tekenen, met naam, e-mail, IP en tijdstip) en `toestelakkoord` (de persoon tekende bij het koppelen, met dezelfde sleutel, de verklaring dat het toestel van hem is; de verklaringstekst, haar SHA-256 en de handtekening staan in die registratie). Beide zijn op te vragen bij de eigenaar en met dezelfde stappen na te rekenen; `met_verklaring_persoon = true` betekent dat de tweede verklaring door de persoon zelf is getekend.
`organisatie` zegt wie de organisatie is (naam, ondernemingsnummer) en hoe haar identiteit vaststaat: `mandaat_eid` verwijst naar een registratie waarin de beheerder een mandaat-pdf met zijn Belgische eID tekende (PAdES, gekwalificeerde handtekening; naam en certificaat in die registratie, de getekende pdf bij de eigenaar). Ontbreekt dat, dan staat er eerlijk: "verklaring van bevoegdheid, niet onafhankelijk geverifieerd".

**Stap 4 — Wanneer, getuige 1 (Sectigo).**
Sla `tsa.token_b64` op als `tijdstempel.tsr` (base64 gedecodeerd) en controleer:
```
openssl ts -reply -token_in -in tijdstempel.tsr -text            # lees 'Message data' (= merkle.root) en 'Time stamp'
openssl ts -verify -token_in -in tijdstempel.tsr -digest <merkle.root> -CAfile sectigo-chain.pem
```
De Sectigo-keten haalt u zelf op (crt.sh of sectigo.com), niet uit de bundel: zo vertrouwt u niets van ons.

**Stap 5 — Wanneer, getuige 2 (Bitcoin).**
```
pip install opentimestamps-client
ots verify -d <merkle.root> bitcoin.ots
```
Uitkomst: "Success! Bitcoin block <hoogte> attests existence as of <datum>". Het commando controleert tegen een Bitcoin-node of, standaard, tegen publieke blokexplorers. `manifest.bitcoin.status = "pending"` betekent: ingediend, nog geen blok; download de bundel dan later opnieuw.

**Stap 6 — Grootboek.**
`ledger.record` bevat `index`, `prev`, `time` en `record`. SHA-256 over de canonieke JSON van die vier velden = `ledger.tx_id`, en `record.root` = `merkle.root`. `prev` verwijst naar het vorige record: één record wijzigen breekt de keten.

**Stap 7 — Handtekening Vidimus.**
`manifest.sig` is een Ed25519-handtekening over de exacte bytes van `manifest.json`, te controleren met `platform-cert.pem`. Wijzigt iemand het manifest, dan faalt dit.

## 4. Wat een afwijking betekent

| Controle faalt | Betekenis |
|---|---|
| inhoud (stap 1) | een bestand of veld is niet meer wat er verankerd is; het script noemt de bijlage |
| Merkle (stap 2) | de vingerafdruk zit niet in deze batch |
| handtekening indiener | niet getekend met de sleutel van deze persoon |
| tijdstempel / Bitcoin | de wortel bestond niet vóór dat tijdstip, of het token hoort bij een andere wortel |
| handtekening Vidimus | het manifest is achteraf gewijzigd |

Een gewijzigde inhoud laat alle andere controles intact. Zo blijkt niet alleen dát er iets veranderd is, maar ook wat.

## 5. Grenzen, eerlijk

- Vidimus bewijst dat een inhoud bestond op een tijdstip en wie ze tekende. Niet dat de inhoud waar is: een foute temperatuur blijft een foute temperatuur, maar wel verankerd als "dit is wat toen gemeld werd".
- Een correctie is nooit een wijziging maar een nieuwe registratie met eigen hash en tijdstip. Beide versies blijven bestaan.
- Is de inhoud gewist na de bewaartermijn, dan bewijst de bundel nog dát iets bestond, wie tekende en wanneer, niet wát.
- Zonder salt (publieke bundel van een stroom met persoonsgegevens) is de inhoud niet herrekenbaar; de rest wel.

Vidimus · VO Initiatives BV · vidimus.be/verificatie.html · oskar@vo-initiatives.com

## Hoe sterk is de handtekening van de persoon?
`manifest.signer.bevestiging` zegt hoe de persoon tekende: `{"via":"passkey","biometrie":true}` betekent dat het toestel een Face ID- of vingerafdrukcontrole (WebAuthn, vlag *user verified*) eiste vóór de toestelsleutel mocht tekenen; `{"via":"enclave","biometrie":true}` is de iOS-app: een P-256-sleutel in de Secure Enclave die pas tekent na Face ID of pincode (ES256 over de registratie-hash, publieke sleutel bij de indiener); `{"via":"toestel"}` is een toestelsleutel zonder biometrie; `"reden":"offline-wachtrij"` betekent dat de bevestiging zonder verbinding werd gezet en later gesynchroniseerd. Ontbreekt het veld, dan is de registratie ouder dan 10 september 2026. De toestelsleutel zelf bewijst het toestel, niet de persoon: wie het toestel kreeg staat in de verklaring werkgever (`signer.mandaat`), en de organisatie daarachter in `organisatie.kenmerk`.
