# Vidimus — verificatiehandleiding voor deskundigen

**Specificatie v1.0 · 12 september 2026.** Dit document is de vaste beschrijving van de bewijsketen: canonieke JSON en veldvolgorde, HMAC-SHA-256 met een salt per stroom voor persoonsgegevens, hashketen in het grootboek (prev), Merkle-regels (oneven blad wordt gedupliceerd), ankerinterval van 5 minuten, RFC 3161-tijdstempel en OpenTimestamps. Wijzigingen krijgen een nieuw versienummer; oude bundels blijven onder hun eigen versie na te rekenen.

Voor wie een bewijsbundel van Vidimus moet narekenen zonder Vidimus te vertrouwen: gerechtsdeskundige, auditor, advocaat, IT-dienst van een tegenpartij. Alles hieronder werkt zonder account en zonder Vidimus-software; alleen de bundel (.zip) is nodig. Stappen 1 tot 4, 6 en 7 werken offline. Stap 5 (Bitcoin) vraagt één opzoeking in een publieke blockexplorer, of een eigen Bitcoin-node.

## 1. Wat in de bundel zit

| Bestand | Inhoud |
|---|---|
| `manifest.json` | alle feiten en tussenwaarden: vingerafdruk, Merkle-pad en -wortel, batch, handtekeningen, tijdstempel, grootboekrecord, Bitcoin-status |
| `manifest.sig` | Ed25519-handtekening van Vidimus over de exacte bytes van `manifest.json` |
| `registration.json` | de originele inhoud van de registratie in canonieke vorm (ontbreekt als de inhoud na de bewaartermijn gewist is) |
| `attachments/…` | de originele bijlagen: foto's, pdf's, cmr, metingen (idem) |
| `signer-cert.pem`, `org-ca.pem` | certificaat van de indiener en de organisatie die het uitgaf |
| `platform-cert.pem` | certificaat van Vidimus (voor `manifest.sig`) |
| `tijdstempel` (in manifest, `tsa.token_b64`) | RFC 3161-token van Sectigo over de Merkle-wortel |
| `bitcoin.ots` | OpenTimestamps-bewijs: wortel → Bitcoin-blok |
| `verify_bundle.py` | referentiescript dat alle controles uitvoert |

## 2. Snel: één commando

```
pip install cryptography rfc3161ng opentimestamps-client   # eenmalig; zonder de laatste twee blijven tijdstempel en Bitcoin op null
python3 verify_bundle.py bundel.zip
```

Uitkomst per controle: `true` (klopt), `false` (klopt niet), `null` (niet controleerbaar in deze omgeving, met reden in `notes`). `"ok": true` betekent: geen enkele controle faalde. Onderaan telt het script hoeveel controles het echt heeft nagerekend en hoeveel niet (null). Een null is geen bevestiging: installeer wat in `notes` staat, of reken die stap met de hand na.

## 3. Met de hand, stap voor stap

Wie het script niet vertrouwt, doet hetzelfde met standaardgereedschap. Alle verwachte waarden staan in `manifest.json`.

**Stap 1 — Inhoud (wat).**
`registration.json` is de canonieke JSON (sleutels gesorteerd, geen witruimte, UTF-8). Bereken per bijlage `sha256sum attachments/<naam>`. Bouw het object `{"canon": "vidimus-json-1", "payload": <registration.json>, "attachments": {<naam>: <sha256>, …}}`, canoniek geserialiseerd, en neem daar SHA-256 van. Resultaat = `registration.hash` in het manifest.
Bijlagen tellen op **naam**, gesorteerd; de volgorde van uploaden speelt geen rol. Bij stromen met persoonsgegevens is de hash HMAC-SHA256 met de salt uit `disclosure.salt` (alleen in de bundel van de eigenaar).

**Hele map in één registratie.** Is de bijlage `attachments/manifest.json` een map-manifest (`"type": "vidimus-manifest"`), dan staan de bestanden zelf niet in de bundel: ze zijn nooit geüpload. Het manifest noemt per bestand het pad en de SHA-256. Eén bestand nakijken: `sha256sum <bestand>` en die waarde opzoeken in het manifest; het manifest zelf hangt via stap 1 aan de registratie (`sha256sum attachments/manifest.json` = de waarde onder `attachments` én `document_sha256` in `registration.json`). Een hele map in één keer: `python3 vidimus-map.py controleer attachments/manifest.json <map>` (script op `/tools/vidimus-map.py`, werkt offline).

**Vastgelegde webpagina.** Bij een registratie met `"type": "webcapture"` zijn de bijlagen `pagina.html` (de HTML zoals de server van Vidimus ze ontving), `headers.json` (verzoek, omleidingen, antwoordheaders, TLS-certificaat van de site) en, als er een browser was, `schermbeeld.png` en `dom.html`. `sha256sum attachments/pagina.html` = `document_sha256` in `registration.json`. Open `pagina.html` niet zomaar in een browser met toegang tot uw netwerk: het is inhoud van een derde. De registratie toont wat op dat adres aan onze server werd aangeboden op dat moment; ze zegt niets over wat een andere bezoeker te zien kreeg.

**Stap 2 — Batch (Merkle).**
Neem de vingerafdruk uit stap 1 en loop het pad `merkle.path` af: op elke stap de twee waarden sorteren, aan elkaar plakken (als bytes) en SHA-256 nemen. Eindresultaat = `merkle.root`.

**Stap 3 — Wie (handtekening indiener).**
`registration.signature_b64` is een Ed25519-handtekening over de bytes van de vingerafdruk (hex gedecodeerd), te controleren met de publieke sleutel in `signer-cert.pem`. Controleer dat dit certificaat is uitgegeven door `org-ca.pem`. Met gewone openssl: `openssl x509 -in signer-cert.pem -pubkey -noout > indiener.pub`, zet de vingerafdruk als bytes in `hash.bin` en `signature_b64` gedecodeerd in `sig.bin`, dan `openssl pkeyutl -verify -pubin -inkey indiener.pub -rawin -in hash.bin -sigfile sig.bin`, en `openssl verify -CAfile org-ca.pem signer-cert.pem`.
`signer.key_custody = "device"` betekent: de privésleutel stond op het toestel van de indiener, niet bij Vidimus. `"platform-held"` betekent: een systeemsleutel van de organisatie (koppeling, poort, sensor) die Vidimus bewaart; de handtekening toont dan welk systeem van welke organisatie indiende, niet welke persoon.
`signer.mandaat` verwijst naar twee eerdere, zelf verankerde registraties in de stroom 'akkoorden' van de organisatie: `werkgever` (de beheerder verklaarde bij het uitnodigen wie de persoon is en dat hij mag tekenen, met naam, e-mail, IP en tijdstip) en `toestelakkoord` (de persoon tekende bij het koppelen, met dezelfde sleutel, de verklaring dat het toestel van hem is; de verklaringstekst, haar SHA-256 en de handtekening staan in die registratie). Beide zijn op te vragen bij de eigenaar en met dezelfde stappen na te rekenen; `met_verklaring_persoon = true` betekent dat de tweede verklaring door de persoon zelf is getekend.
`organisatie` zegt wie de organisatie is (naam, ondernemingsnummer) en hoe haar identiteit vaststaat: `mandaat_eid` verwijst naar een registratie waarin de beheerder een mandaat-pdf met zijn Belgische eID tekende (PAdES, gekwalificeerde handtekening; naam en certificaat in die registratie, de getekende pdf bij de eigenaar). Ontbreekt dat, dan staat er eerlijk: "verklaring van bevoegdheid, niet onafhankelijk geverifieerd".

**Stap 4 — Wanneer, getuige 1 (Sectigo).**
Sla `tsa.token_b64` op als `tijdstempel.tsr` (base64 gedecodeerd) en controleer:
```
openssl ts -reply -token_in -in tijdstempel.tsr -text      # 'Message data' moet gelijk zijn aan merkle.root; 'Time stamp' is het tijdstip
openssl cms -verify -inform DER -in tijdstempel.tsr -purpose timestampsign -out /dev/null -CAfile <rootcertificaten van uw systeem>
```
Het tweede commando controleert de handtekening van Sectigo en de keten (Signer → CA R41 → Root R46 → USERTrust RSA) tot een rootcertificaat dat al op uw computer staat, niet van ons. Uitkomst: `Verification successful`. Rootcertificaten: op Linux `/etc/ssl/certs/ca-certificates.crt`; op macOS `security find-certificate -a -p /System/Library/Keychains/SystemRootCertificates.keychain > roots.pem`.
Let op: `openssl ts -verify` geeft bij deze Sectigo-tokens in OpenSSL 3 de fout `ess cert id not found`, ook als het token in orde is. Gebruik daarom `cms -verify` samen met de vergelijking van 'Message data'.

**Stap 5 — Wanneer, getuige 2 (Bitcoin).**
```
pip install opentimestamps-client
ots info bitcoin.ots                                        # pad van de wortel naar het blok
ots --no-bitcoin verify -d <merkle.root> bitcoin.ots        # toont: "check that Bitcoin block <hoogte> has merkleroot <waarde>"
```
Zoek dat blok op in een publieke blockexplorer (bv. blockstream.info of mempool.space) en vergelijk de merkle-wortel. Gelijk = de wortel bestond vóór het tijdstip van dat blok. Met een eigen Bitcoin-node doet `ots verify -d <merkle.root> bitcoin.ots` alles in één stap. Zonder `block_height` in `manifest.bitcoin` is er nog geen blok; download de bundel dan later opnieuw.
Bitcoin bewijst alleen "vóór dit blok". Het precieze tijdstip komt van het tijdstempel in stap 4; bij oudere registraties kan het Bitcoin-blok dagen of weken later liggen.

**Stap 6 — Grootboek.**
`ledger.record` bevat `index`, `prev`, `time` en `record`. SHA-256 over de canonieke JSON van die vier velden = `ledger.tx_id`, en `record.root` = `merkle.root`. `prev` verwijst naar het vorige record: één record wijzigen breekt de keten.

**Stap 7 — Handtekening Vidimus.**
`manifest.sig` is een Ed25519-handtekening (64 bytes, ruw) over de exacte bytes van `manifest.json`, te controleren met `platform-cert.pem`: `openssl x509 -in platform-cert.pem -pubkey -noout > vidimus.pub` en `openssl pkeyutl -verify -pubin -inkey vidimus.pub -rawin -in manifest.json -sigfile manifest.sig`. Wijzigt iemand het manifest, dan faalt dit.

## 4. Wat een afwijking betekent

| Controle faalt | Betekenis |
|---|---|
| inhoud (stap 1) | een bestand of veld is niet meer wat er verankerd is; het script noemt de bijlage |
| Merkle (stap 2) | de vingerafdruk zit niet in deze batch |
| handtekening indiener | niet getekend met de sleutel van deze indiener |
| tijdstempel / Bitcoin | de wortel bestond niet vóór dat tijdstip, of het token hoort bij een andere wortel |
| handtekening Vidimus | het manifest is achteraf gewijzigd |

Een gewijzigde inhoud laat alle andere controles intact. Zo blijkt niet alleen dát er iets veranderd is, maar ook wat.

## 5. Grenzen, eerlijk

- Vidimus bewijst dat een inhoud bestond op een tijdstip en met welke sleutel ze getekend werd. Niet dat de inhoud waar is: een foute temperatuur blijft een foute temperatuur, maar wel verankerd als "dit is wat toen gemeld werd".
- Een correctie is nooit een wijziging maar een nieuwe registratie met eigen hash en tijdstip. Beide versies blijven bestaan.
- Is de inhoud gewist na de bewaartermijn, dan bewijst de bundel nog dát iets bestond, wie tekende en wanneer, niet wát.
- Zonder salt (publieke bundel van een stroom met persoonsgegevens) is de inhoud niet herrekenbaar; de rest wel.

Vidimus · VO Initiatives BV · vidimus.be/verificatie.html · oskar@vo-initiatives.com

## Hoe sterk is de handtekening van de persoon?
`manifest.signer.bevestiging` zegt hoe de persoon tekende: `{"via":"passkey","biometrie":true}` betekent dat het toestel een Face ID- of vingerafdrukcontrole (WebAuthn, vlag *user verified*) eiste vóór de toestelsleutel mocht tekenen; `{"via":"enclave","biometrie":true}` is de iOS-app: een P-256-sleutel in de Secure Enclave die pas tekent na Face ID of pincode (ES256 over de registratie-hash, publieke sleutel bij de indiener); `{"via":"toestel"}` is een toestelsleutel zonder biometrie; `"reden":"offline-wachtrij"` betekent dat de bevestiging zonder verbinding werd gezet en later gesynchroniseerd. Ontbreekt het veld, dan is de registratie ouder dan 10 september 2026. De toestelsleutel zelf bewijst het toestel, niet de persoon: wie het toestel kreeg staat in de verklaring werkgever (`signer.mandaat`), en de organisatie daarachter in `organisatie.kenmerk`.
