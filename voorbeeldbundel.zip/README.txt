Vidimus-bewijsbundel. Controleer zelfstandig: python3 verify_bundle.py <zip>
hash = wat · handtekening = wie · tijdstempel = wanneer · merkle+grootboek = onwijzigbaar · zie manifest.json