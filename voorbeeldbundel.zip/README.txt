Bewijsbundel van registratie reg_85ad7003baf0, gemaakt op 2026-09-28T15:02:31.639386+00:00 (UTC).

Wat erin zit
manifest.json + manifest.sig   wat werd vastgelegd (ook de groep, het logboekrecord en de tijdstempel van een onafhankelijke dienst), ondertekend met de platformsleutel van Vidimus
registration.json, attachments/ de inhoud en de bestanden (tenzij gewist; bij een vertrouwelijke stroom versleuteld)
signer-cert.pem, org-ca.pem    wie tekende (soms ook org-ica.pem)
gekwalificeerd.tsr             de gekwalificeerde tijdstempel (als die er al is)
bitcoin.ots                    het Bitcoin-bewijs (als het blok er al was)
bewijs.ers + vingerafdruk-invoer.json   voor de validatiesoftware van de Europese Commissie (DSS)
verify_bundle.py, VERIFICATIE.md        het script en de handleiding

Drie manieren om na te rekenen. Elke manier staat op zichzelf.
1  python3 verify_bundle.py <deze zip>
   Verwacht: "UITKOMST: ongewijzigd · …controles stemmen overeen", bij een verse bundel met "1 volgt nog" (Bitcoin). Wat hier niet kan (Bitcoin zonder internet, een ontbrekende bibliotheek), staat er als "niet nagerekend" met de reden. Bij een afwijking noemt het script het bestand.
   Vertrouwt u de afzender niet? Haal het script bij Vidimus: https://app.vidimus.be/verify_bundle.py (SHA-256: https://app.vidimus.be/verify_bundle.py.sha256).
2  openssl, stap voor stap: VERIFICATIE.md §3.
3  EU DSS, "Validation with archival data": bewijs.ers + vingerafdruk-invoer.json (VERIFICATIE.md stap 8).

Wat deze bundel niet bevat
- het eID-mandaat als pdf: op te vragen bij de organisatie (het bevat het rijksregisternummer);
- het geheime getal (salt) van oudere registraties met persoonsgegevens: alleen als de organisatie het vrijgaf;
- de leesbare inhoud, bij een vertrouwelijke stroom: ontsleutelen met verify_bundle.py --herstel.

Bitcoin vraagt internet; EU DSS ook. De rest werkt offline.
