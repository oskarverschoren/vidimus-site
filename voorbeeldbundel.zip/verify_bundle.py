#!/usr/bin/env python3
"""Vidimus — onafhankelijke verificatie van een bewijsbundel (zip).

Zelfstandig: alleen Python 3 + het pakket 'cryptography'. Geen Vidimus-code, geen netwerk, geen account.
Gebruik:  python3 verify_bundle.py bundel.zip
Wat het controleert:
  1. hash      — de registratie (canonieke JSON) + bijlagen herrekend = hash in manifest
  2. merkle    — hash + merkle-pad (sorted pairs) → wortel in manifest
  3. signature — Ed25519-handtekening van de indiener over de hash, cert hoort bij die sleutel, cert door org-CA
  4. platform  — Ed25519-handtekening van Vidimus over manifest.json (platform-cert.pem)
  5. ledger    — de wortel staat in het meegeleverde grootboekrecord (tx_id herrekend uit het record)
  6. tsa       — RFC 3161-token aanwezig en, indien 'rfc3161ng' geïnstalleerd, cryptografisch geldig voor de wortel
Uitkomst: JSON met per check True/False/None (None = niet controleerbaar in deze omgeving), en 'ok'.
"""
import base64
import hashlib
import hmac
import json
import math
import sys
import zipfile
from datetime import datetime, timezone

CANON_VERSION = "vidimus-json-1"


def canon_bytes(obj) -> bytes:
    def chk(o):
        if isinstance(o, float) and not math.isfinite(o):
            raise ValueError("NaN")
        if isinstance(o, dict):
            [chk(v) for v in o.values()]
        elif isinstance(o, list):
            [chk(v) for v in o]
    chk(obj)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def _parent(a, b):
    lo, hi = sorted((a, b))
    return hashlib.sha256(bytes.fromhex(lo) + bytes.fromhex(hi)).hexdigest()


def merkle_verify(leaf, path, root):
    h = leaf
    for s in path:
        h = _parent(h, s)
    return h == root


def _ed_verify(public_pem: str, data: bytes, sig: bytes) -> bool:
    from cryptography.hazmat.primitives import serialization
    from cryptography.exceptions import InvalidSignature
    pub = serialization.load_pem_public_key(public_pem.encode())
    try:
        pub.verify(sig, data)
        return True
    except InvalidSignature:
        return False


def _cert_pub_pem_and_chain(cert_pem: str, ca_pem: str):
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization
    from cryptography.exceptions import InvalidSignature
    c = x509.load_pem_x509_certificate(cert_pem.encode())
    ca = x509.load_pem_x509_certificate(ca_pem.encode())
    pub_pem = c.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode()
    try:
        ca.public_key().verify(c.signature, c.tbs_certificate_bytes)
        chain = c.issuer == ca.subject
    except InvalidSignature:
        chain = False
    return pub_pem, chain


def _bevestiging_tekst(b):
    if not b: return None
    if b.get("via") == "enclave": return "Face ID / pincode op het toestel (Secure Enclave, gebruiker geverifieerd)"
    if b.get("via") == "passkey" and b.get("biometrie"): return "Face ID / vingerafdruk op het toestel (passkey, gebruiker geverifieerd)"
    if b.get("via") == "passkey": return "toestelsleutel; passkey aanwezig maar offline getekend (wachtrij)"
    return "toestelsleutel zonder biometrie"

def _tst_serial(token_b64) -> str:
    """Serienummer van het tijdstempel zelf (TSTInfo.serialNumber), zoals `openssl ts -text` het toont.
    Het veld 'serial' dat timestamp.py bewaart is het serienummer van het ondertekenaarscertificaat, niet van het token."""
    if not token_b64: return ""
    try:
        from pyasn1.codec.der import decoder
        import rfc3161ng
        t, _ = decoder.decode(base64.b64decode(token_b64), asn1Spec=rfc3161ng.TimeStampToken())
        return format(int(t.tst_info["serialNumber"]), "X")
    except Exception:
        return ""

def _bitcoin_bewijs(ots: bytes, root_hex: str, hoogte: int):
    """(True/False/None, uitleg). Rekent het OpenTimestamps-bewijs na: begint het bij de batchwortel, leidt het naar een
    Bitcoin-blok, en — online — klopt de merkle-wortel in dat bewijs met wat het blok volgens blockstream.info bevat?"""
    try:
        from opentimestamps.core.timestamp import DetachedTimestampFile
        from opentimestamps.core.notary import BitcoinBlockHeaderAttestation
        from opentimestamps.core.serialize import BytesDeserializationContext
    except ImportError:
        return None, "bewijsbestand aanwezig; installeer 'opentimestamps-client' (pip) om het na te rekenen, of: ots --no-bitcoin verify -d <merkle.root> bitcoin.ots en de blok-merkle-wortel in een blockexplorer vergelijken"
    try:
        d = DetachedTimestampFile.deserialize(BytesDeserializationContext(ots))
    except Exception as e:
        return False, f"bitcoin.ots is geen geldig OpenTimestamps-bestand ({e.__class__.__name__})"
    if root_hex and d.timestamp.msg.hex() != root_hex.lower():
        return False, "het bewijs begint niet bij de batchwortel uit het manifest"
    blokken = {}
    for msg, att in d.timestamp.all_attestations():
        if isinstance(att, BitcoinBlockHeaderAttestation): blokken[att.height] = msg   # msg = merkle-wortel van het blok (little-endian)
    if not blokken:
        return None, "bewijs bevat nog geen Bitcoin-blok (wacht op bevestiging; bundel later opnieuw downloaden)"
    if hoogte not in blokken:
        return False, f"manifest zegt blok {hoogte}, bewijs wijst naar blok {sorted(blokken)}"
    verwacht = blokken[hoogte][::-1].hex()
    try:
        import urllib.request
        h = urllib.request.urlopen(f"https://blockstream.info/api/block-height/{hoogte}", timeout=8).read().decode().strip()
        info = json.loads(urllib.request.urlopen(f"https://blockstream.info/api/block/{h}", timeout=8).read().decode())
        if info.get("merkle_root") == verwacht:
            return True, f"pad van batchwortel naar Bitcoin-blok {hoogte} klopt; merkle-wortel van het blok bevestigd tegen blockstream.info ({info.get('timestamp') and datetime.fromtimestamp(info['timestamp'], tz=timezone.utc).isoformat()})"
        return False, f"blok {hoogte}: merkle-wortel in het bewijs ({verwacht[:16]}…) verschilt van blockstream.info ({str(info.get('merkle_root'))[:16]}…)"
    except Exception:
        return True, f"pad van batchwortel naar Bitcoin-blok {hoogte} klopt (offline: blokinhoud niet vergeleken; controleer merkle-wortel {verwacht} op twee explorers)"

def verify_bundle(path) -> dict:
    checks = {"hash": None, "merkle": None, "signature": None, "platform_signature": None, "ledger": None, "tsa": None}
    notes = []
    with zipfile.ZipFile(path) as z:
        names = set(z.namelist())
        manifest_raw = z.read("manifest.json")
        m = json.loads(manifest_raw)
        ots_bytes = z.read("bitcoin.ots") if "bitcoin.ots" in names else None

        # 4. platform-handtekening over manifest.json (exacte bytes)
        try:
            sig = z.read("manifest.sig")
            pcert = z.read("platform-cert.pem").decode()
            ca_pem = z.read("org-ca.pem").decode() if "org-ca.pem" in names else pcert
            ppub, pchain = _cert_pub_pem_and_chain(pcert, ca_pem)
            checks["platform_signature"] = _ed_verify(ppub, manifest_raw, sig) and pchain
        except Exception as e:
            checks["platform_signature"] = False; notes.append(f"platform: {e}")

        # 1. hash herrekenen (registratie + bijlagen)
        reg = m["registration"]
        if "registration.json" in names:
            payload = json.loads(z.read("registration.json"))
            att_hashes = {}
            enc = m.get("encrypted_attachments") or {}
            for name in reg.get("attachments", {}):
                fn = f"attachments/{name}"
                if name in enc:
                    att_hashes[name] = reg["attachments"][name]  # client-side versleuteld: bundel bevat cijfertekst; de verankerde hash is die van het origineel
                    notes.append(f"bijlage {name}: client-side versleuteld (E2E) — hash van het origineel is verankerd; ontsleutel lokaal om het bestand zelf na te rekenen")
                elif fn in names:
                    att_hashes[name] = hashlib.sha256(z.read(fn)).hexdigest()
                else:
                    att_hashes[name] = reg["attachments"][name]  # gewist/niet meegeleverd → vertrouw manifest, meld
                    notes.append(f"bijlage {name} niet in bundel (gewist of niet meegeleverd)")
            digest_input = {"canon": m["canon"], "payload": payload, "attachments": att_hashes}
            data = canon_bytes(digest_input)
            if reg["hash_type"] == "sha256":
                calc = hashlib.sha256(data).hexdigest()
                checks["hash"] = calc == reg["hash"]
            elif reg["hash_type"] == "hmac-sha256":
                salt_hex = m.get("disclosure", {}).get("salt")
                if salt_hex:
                    calc = hmac.new(bytes.fromhex(salt_hex), data, hashlib.sha256).hexdigest()
                    checks["hash"] = calc == reg["hash"]
                else:
                    checks["hash"] = None; notes.append("gesleutelde hash: salt niet meegeleverd (bewust, AVG) — inhoud niet herrekenbaar zonder salt")
        else:
            notes.append("registration.json niet in bundel (gewist) — alleen ketting controleerbaar")

        # 2. merkle
        mk = m["merkle"]
        checks["merkle"] = merkle_verify(reg["hash"], mk["path"], mk["root"])

        # 3. handtekening indiener over de hash
        try:
            scert = z.read("signer-cert.pem").decode()
            ca_pem = z.read("org-ca.pem").decode() if "org-ca.pem" in names else scert
            spub, schain = _cert_pub_pem_and_chain(scert, ca_pem)
            checks["signature"] = _ed_verify(spub, bytes.fromhex(reg["hash"]), base64.b64decode(reg["signature_b64"])) and schain
        except Exception as e:
            checks["signature"] = False; notes.append(f"signer: {e}")

        # 5. grootboek: tx_id = sha256(canon(index,prev,time,record)) en record.root == wortel
        lg = m.get("ledger")
        if lg and lg.get("record"):
            body = {k: lg["record"][k] for k in ("index", "prev", "time", "record")}
            calc = hashlib.sha256(canon_bytes(body)).hexdigest()
            checks["ledger"] = (calc == lg["tx_id"]) and lg["record"]["record"].get("root") == mk["root"]
        else:
            checks["ledger"] = None; notes.append("grootboekrecord niet meegeleverd (extern na te kijken via tx_id)")

        # 6. tsa
        ts = m.get("tsa", {})
        if ts.get("token_b64"):
            try:
                import rfc3161ng
                from pyasn1.codec.der import decoder as _dec, encoder as _enc
                from pyasn1_modules import rfc2315 as _cms
                token = base64.b64decode(ts["token_b64"])
                ci, _ = _dec.decode(token, asn1Spec=_cms.ContentInfo())
                sd, _ = _dec.decode(ci["content"], asn1Spec=_cms.SignedData())
                ok = False
                for c in sd["certificates"]:  # de TSA-signing-cert zit in het token zelf
                    try:
                        if rfc3161ng.check_timestamp(token, certificate=_enc.encode(c["certificate"]), digest=bytes.fromhex(mk["root"]), hashname="sha256"):
                            ok = True; break
                    except Exception:
                        continue
                checks["tsa"] = ok
            except ImportError:
                checks["tsa"] = None; notes.append("tsa: token aanwezig; installeer 'rfc3161ng' voor cryptografische controle")
            except Exception as e:
                checks["tsa"] = False; notes.append(f"tsa: {e}")
        else:
            checks["tsa"] = None; notes.append("tsa: geen token (offline/test-tijdstempel)")

    btc = m.get("bitcoin")
    if btc:
        if btc.get("status") == "bitcoin" and btc.get("block_height"):
            # 15/09: het .ots-bewijs zelf narekenen (niet alleen het manifest geloven): het pad van de wortel naar het Bitcoin-blok,
            # en — als er verbinding is — de merkle-wortel van dat blok vergelijken met een publieke explorer (blockstream.info).
            if "bitcoin.ots" not in names:
                checks["bitcoin"] = None; notes.append("bitcoin: blokhoogte in manifest, maar bitcoin.ots ontbreekt in de bundel")
            else:
                uit = _bitcoin_bewijs(ots_bytes, mk.get("root"), int(btc.get("block_height")))
                checks["bitcoin"] = uit[0]; notes.append("bitcoin: " + uit[1])
        else:
            checks["bitcoin"] = None; notes.append("bitcoin: ingediend bij OpenTimestamps, wacht op bevestiging in een Bitcoin-blok (meestal 1–6 u); bundel later opnieuw downloaden voor het volledige bewijs")
    fab = m.get("fabric")
    if fab and fab.get("tx_id"):
        checks["fabric"] = None   # feit uit het manifest; live-controle tegen een peer gebeurt door de verificatiepagina of door de deskundige zelf
        notes.append(f"fabric: wortel als transactie {fab['tx_id'][:16]}… op kanaal {fab.get('channel')} (blok {fab.get('block')}); controleer tegen een peer, zie manifest.fabric.how_to_verify")
    co = m.get("co_signatures") or []
    if co:
        goed = []
        for c in co:
            try: goed.append(_ed_verify(c["public_key_pem"], bytes.fromhex(reg["hash"]), base64.b64decode(c["signature_b64"])))
            except Exception: goed.append(False)
        checks["counter_signature"] = all(goed)   # alleen aanwezig als er samen getekend is
        if not all(goed): notes.append("tegenhandtekening: minstens één handtekening klopt niet met de meegeleverde sleutel")
    hard = [checks["merkle"], checks["signature"], checks["platform_signature"]]
    ok = all(hard) and checks["hash"] is not False and checks["ledger"] is not False and checks["tsa"] is not False
    reg = m["registration"]; sg = m.get("signer") or {}; mk = m.get("merkle") or {}; ts = m.get("tsa") or {}; lg = m.get("ledger") or {}
    # publiek-veilige details per controle (geen inhoud, geen salt, geen sleutels)
    details = {
        "hash": {"type": reg.get("hash_type"), "value": reg.get("hash"), "attachments": len(reg.get("attachments") or {}), "canon": m.get("canon"),
                 "shredded": bool(reg.get("shredded"))},
        "merkle": {"root": mk.get("root"), "batch": mk.get("batch"), "count": mk.get("count"), "path_len": len(mk.get("path") or []), "convention": m.get("merkle_convention")},
        "signature": {"algorithm": "Ed25519", "subject_cn": sg.get("subject_cn"), "subject_org": sg.get("subject_org"), "issuer_cn": sg.get("issuer_cn"),
                      "serial": sg.get("serial"), "key_custody": sg.get("key_custody"), "not_before": sg.get("not_before"), "not_after": sg.get("not_after"),
                      "bevestiging": _bevestiging_tekst(sg.get("bevestiging"))},
        "mandaat": sg.get("mandaat"),
        "platform_signature": {"algorithm": "Ed25519", "signed": "manifest.json (exacte bytes)", "platform": (m.get("platform") or {}).get("name"), "operator": (m.get("platform") or {}).get("operator")},
        "ledger": {"name": lg.get("name"), "channel": lg.get("channel"), "index": lg.get("index"), "tx_id": lg.get("tx_id"),
                   "prev": ((lg.get("record") or {}).get("prev")), "time": ((lg.get("record") or {}).get("time"))},
        "counter_signature": {"count": len(m.get("co_signatures") or []), "names": ", ".join(c.get("naam") or "?" for c in (m.get("co_signatures") or [])) or None,
                              "orgs": ", ".join(c.get("org") or "" for c in (m.get("co_signatures") or []) if c.get("org")) or None,
                              "times": ", ".join((c.get("time") or "")[:19] for c in (m.get("co_signatures") or [])) or None,
                              "via": ", ".join(c.get("via") or "" for c in (m.get("co_signatures") or [])) or None},
        "tsa": {"provider": ts.get("provider"), "url": ts.get("url"), "time": ts.get("time"), "serial": _tst_serial(ts.get("token_b64")) or None,
                "cert_serial": ts.get("serial"), "tier": ts.get("tier", "standard"), "standard": "RFC 3161"},
    }
    og = m.get("organisatie") or {}
    if og:
        details["signature"]["organisatie"] = og.get("naam"); details["signature"]["organisatie_identiteit"] = og.get("identiteit")
        if og.get("mandaat_eid"): details["signature"]["mandaat_eid"] = (og["mandaat_eid"] or {}).get("registratie"); details["signature"]["mandaat_eid_moment"] = (og["mandaat_eid"] or {}).get("moment")
    md = sg.get("mandaat") or {}
    if md:
        details["signature"].update({"mandaat_werkgever": (md.get("werkgever") or {}).get("registratie"), "mandaat_werkgever_moment": (md.get("werkgever") or {}).get("moment"),
                                     "toestelakkoord": (md.get("toestelakkoord") or {}).get("registratie"), "toestelakkoord_moment": (md.get("toestelakkoord") or {}).get("moment"),
                                     "verklaring_persoon": "ja" if md.get("met_verklaring_persoon") else "nee"})
    if fab and fab.get("tx_id"):
        details["fabric"] = {"network": fab.get("network"), "channel": fab.get("channel"), "chaincode": fab.get("chaincode"), "msp": fab.get("msp"), "tx_id": fab.get("tx_id"),
                             "block": fab.get("block"), "submitted": fab.get("submitted"), "key": fab.get("key"), "root": mk.get("root"), "how_to_verify": fab.get("how_to_verify")}
    if btc:
        details["bitcoin"] = {"network": "Bitcoin", "protocol": "OpenTimestamps", "status": "bevestigd" if checks.get("bitcoin") else ("niet vastgesteld" if checks.get("bitcoin") is False else ("in blok, hier niet nagerekend" if btc.get("block_height") else "wacht op blok")), "block_height": btc.get("block_height"),
                              "submitted": btc.get("submitted"), "confirmed": btc.get("confirmed"), "root": mk.get("root"), "file": btc.get("file"), "how_to_verify": btc.get("how_to_verify")}
    return {"ok": ok, "checks": checks, "notes": notes, "registration_id": reg["id"],
            "anchored_at": ts.get("time"), "signer": sg.get("subject_cn"),
            "root": mk.get("root"), "tx_id": lg.get("tx_id"), "details": details, "created": reg.get("created"),
            "stream": {"name": (m.get("stream") or {}).get("name"), "sector": (m.get("stream") or {}).get("sector")}}


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__); sys.exit(2)
    res = verify_bundle(sys.argv[1])
    print(json.dumps(res, indent=2, ensure_ascii=False))
    namen = {"hash": "inhoud ongewijzigd", "merkle": "in de verankerde batch", "signature": "handtekening indiener", "platform_signature": "handtekening Vidimus",
             "ledger": "grootboekrecord", "tsa": "tijdstempel (RFC 3161)", "bitcoin": "Bitcoin-blok", "fabric": "Fabric-kanaal"}
    print("\nPER CONTROLE")
    for k, v in res["checks"].items():
        print(f"  {'OK  ' if v else ('FOUT' if v is False else '--  ')}  {namen.get(k, k)}{'' if v is not None else '  (niet nagerekend, zie notes)'}")
    open_ = [k for k, v in res["checks"].items() if v is None]
    print("\nRESULTAAT:", "GELDIG" if res["ok"] else "NIET GELDIG",
          f"· {sum(1 for v in res['checks'].values() if v)} van {len(res['checks'])} nagerekend" + (f", {len(open_)} niet nagerekend" if open_ else ""))
    sys.exit(0 if res["ok"] else 1)
