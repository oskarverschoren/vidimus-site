#!/usr/bin/env python3
"""Vidimus — onafhankelijke verificatie van een bewijsbundel (zip).

Zelfstandig: Python 3 + 'cryptography'; voor de tijdstempels (de externe tijdsgetuigen) ook 'rfc3161ng' en 'pyasn1-modules', voor Bitcoin
'opentimestamps-client'. Geen Vidimus-code, geen account.
Gebruik het script van https://app.vidimus.be/verify_bundle.py (SHA-256 op https://app.vidimus.be/verify_bundle.py.sha256),
niet het exemplaar uit een bundel die u niet vertrouwt: wie een bundel vervalst, kan ook het script erin vervangen.
Gebruik:  python3 verify_bundle.py bundel.zip
          python3 verify_bundle.py bundel.zip --herstel herstelsleutel.json [--naar map]
          (vertrouwelijke stroom, laag B: ontsleutelt de bijlagen met het herstelbestand van het bedrijf en de wachtzin,
           en kijkt na dat elk origineel exact de verankerde vingerafdruk heeft; de wachtzin wordt gevraagd, of VIDIMUS_WACHTZIN)
Wat het nagaat (tot tien controles, afhankelijk van wat de bundel bevat):
  1. hash      — de registratie (canonieke JSON) + bijlagen herrekend = vingerafdruk in het manifest
  2. merkle    — vingerafdruk + Merkle-pad (gesorteerde paren) → wortel in het manifest
  3. signature — Ed25519-handtekening van de indiener over de vingerafdruk, certificaat hoort bij die sleutel, uitgegeven door de org-CA
  4. platform  — Ed25519-handtekening van Vidimus over manifest.json (platform-cert.pem)
  5. ledger    — de wortel staat in het meegeleverde logboekrecord (tx_id herrekend uit het record)
  6. tsa       — RFC 3161-token aanwezig en, met 'rfc3161ng', nagerekend voor de wortel
  7. qualified_tsa — (als aanwezig) batchwortel via Merkle-pad in de gekwalificeerde wortel, en het QTSP-token (eIDAS) nagerekend
  8. bitcoin, fabric, counter_signature — als de bundel ze bevat
Per controle: true = stemt overeen, false = wijkt af, null = niet nagerekend (reden in 'redenen' en 'notes').
Wat een mens leest, staat in 'kop' (studie bewijsvoering §5.1): ongewijzigd · inhoud hier niet nagerekend · gewijzigd ·
één controle wijkt af · niet volledig nagerekend · herkomst niet vastgesteld. 'afwijking' noemt per afwijkende controle wat afwijkt.
Uitkomst, technisch: 'status' is een vaste waarde voor programma's, geen oordeel over de inhoud:
  GELDIG      — geen controle wijkt af, de CA en het platformcertificaat zijn de gepubliceerde van Vidimus (vingerafdrukken
                hieronder vastgepind) én minstens één externe tijdsgetuige is nagerekend: een RFC 3161-token met een keten naar
                een vastgepind anker (Sectigo R46, GLOBALTRUST 2015) of een Bitcoin-blok vergeleken met een publieke explorer.
  ONVOLLEDIG  — niets wijkt af, maar herkomst of tijd is niet onafhankelijk vastgesteld (zie 'waarom').
  NIET GELDIG — minstens één controle wijkt af.
'ok' is alleen waar bij GELDIG; 'integriteit' zegt of de bundel intern overeenstemt (vingerafdruk, groep, handtekeningen; niets wijkt af).
Afsluitcode: 0 (GELDIG), 1 (NIET GELDIG), 3 (ONVOLLEDIG), 2 (verkeerd gebruik).
"""
import base64
import hashlib
import hmac
import json
import math
import sys
import threading
import time
import zipfile
from datetime import datetime, timezone

CANON_V1 = "vidimus-json-1"
CANON_VERSION = "vidimus-json-2"   # sinds 26/09/2026: het organisatiekenmerk ("org") zit in de vingerafdruk; v1-bundels blijven geldig
CANON_V3 = "vidimus-json-3"        # sinds 28/09/2026, persoonsgegevens: + "salt" (zout van deze registratie), gewone SHA-256

# 05/10/2026 (doorlichting 0.1): vastgepinde vertrouwensankers. Wat in de bundel zelf zit, bewijst alleen dat de bundel intern klopt;
# herkomst en tijd tellen pas als ze naar deze ankers leiden. Vergelijk de vingerafdrukken met vidimus.be/verificatie.
VIDIMUS_CA_SHA256 = {
    "af56ecef571ed578a449f488be0a4857f4f6af3bfa1507debf3e2f216a218af3": "Vidimus-CA 'VO' (VO Initiatives BV), eerste CA, certificaten tot 06/10/2026, loopt tot 2036-08-13",
    # 06/10/2026: offline aangemaakt en bewaard; tekent alleen de tussen-CA ('Vidimus Tussen-CA 2026') die op de server certificaten uitgeeft
    "662ea695d3372181631c715eae8e6166bfbd89ae7c0533e0e529280ebb59f0ee": "Vidimus Hoofd-CA 2026 (VO Initiatives BV), offline, loopt tot 2046",
}
# Het platformcertificaat (zegel over manifest.json) apart vastgepind: dezelfde CA geeft ook toestel- en systeemcertificaten uit,
# dus "uitgegeven door de Vidimus-CA" alleen bewijst niet dat Vidimus het manifest verzegelde.
VIDIMUS_PLATFORM_SHA256 = {
    "5461e374c0d2f304f9d8a084a2074701cf178530b363a758deaf81a77575b983": "platform.vo (VO Initiatives BV), loopt tot 2028-08-15",
}
MAX_LID_BYTES = 200 * 1024 * 1024     # per bestand in de bundel, uitgepakt (zipbom)
MAX_TOTAAL_BYTES = 1024 * 1024 * 1024
TSA_ANKERS_PEM = {
    # Sectigo-tijdstempels (standaard): keten Signer → CA R41 → Public Time Stamping Root R46 (zelfondertekend, SHA-256 4941b001…).
    # Bewust níet de USERTrust-wortel boven R46: die tekent ook alle web- en e-mailcertificaten van Sectigo.
    "Sectigo Public Time Stamping Root R46": """-----BEGIN CERTIFICATE-----
MIIFejCCA2KgAwIBAgIQeD0FbPqDLn5p+FYidp8CuTANBgkqhkiG9w0BAQwFADBX
MQswCQYDVQQGEwJHQjEYMBYGA1UEChMPU2VjdGlnbyBMaW1pdGVkMS4wLAYDVQQD
EyVTZWN0aWdvIFB1YmxpYyBUaW1lIFN0YW1waW5nIFJvb3QgUjQ2MB4XDTIxMDMy
MjAwMDAwMFoXDTQ2MDMyMTIzNTk1OVowVzELMAkGA1UEBhMCR0IxGDAWBgNVBAoT
D1NlY3RpZ28gTGltaXRlZDEuMCwGA1UEAxMlU2VjdGlnbyBQdWJsaWMgVGltZSBT
dGFtcGluZyBSb290IFI0NjCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIB
AIid2LlFZ50d3ei5JoGaVFTAfEkFm8xaFQ/ZlBBEtEFAgXcUmanU5HYsyAhTXiDQ
kiUvpVdYqZ1uYoZEMgtHES1l1Cc6HaqZzEbOOp6YiTx63ywTon434aXVydmhx7Dx
4IBrAou7hNGsKioIBPy5GMN7KmgYmuu4f92sKKjbxqohUSfjk1mJlAjthgF7Hjx4
vvyVDQGsd5KarLW5d73E3ThobSkob2SL48LpUR/O627pDchxll+bTSv1gASn/hp6
IuHJorEu6EopoB1CNFp/+HpTXeNARXUmdRMKbnXWflq+/g36NJXB35ZvxQw6zid6
1qmrlD/IbKJA6COw/8lFSPQwBP1ityZdwuCysCKZ9ZjczMqbUcLFyq6KdOpuzVDR
3ZUwxDKL1wCAxgL2Mpz7eZbrb/JWXiOcNzDpQsmwGQ6Stw8tTCqPumhLRPb7YkzM
8/6NnWH3T9ClmcGSF22LEyJYNWCHrQqYubNeKolzqUbCqhSqmr/UdUeb49zYHr7A
LL8bAJyPDmubNqMtuaobKASBqP84uhqcRY/pjnYd+V5/dcu9ieERjiRKKsxCG1t6
tG9oj7liwPddXEcYGOUiWLm742st50jGwTzxbMpepmOP1mLnJskvZaN5e45NuzAH
teORlsSuDt5t4BBRCJL+5EZnnw0ezntk9R8QJyAkL6/bAgMBAAGjQjBAMB0GA1Ud
DgQWBBT2d2rdP/0BE/8WoWyCAi/QCj0UJTAOBgNVHQ8BAf8EBAMCAYYwDwYDVR0T
AQH/BAUwAwEB/zANBgkqhkiG9w0BAQwFAAOCAgEACv68sZqZvmHk7JoU7AfTEZ7b
X45u40OrLX/6vzHQAwDg1TB00bWbiwj+7+we60BP8AMsw1h5NCXWxeyvrEVC54Mi
rwVrcF6SFGjRwRoelRuiaZ5FDO4oWhaePjZx3/jkQ7j653CA5WscYqlneLXBEZiY
o6rRNqnsZHZTQ606mlkNpsy3TFMADv5whZmilVEZ83OvydfH2DNL3FTkpZG7+lHS
1DFHMSUB5UtSSeSRg2UWTXwU5oObGjFk/35fC/dlF+nJIXdqsw0TZSS86bi5GRCJ
VjqjnkpZ0Jut7ucEv4PNOIU8ijkMRj17QPjHMtdy+WxBDDSdas/UFTVB/GF+Fofn
OD3iZ4tXxFjPU3EWRcMWx8fcGyzlBfcjeoPNbNC7wfyV9Qkzfk2Bd48jGxG7OThY
Wolc56vmBHqDEfguDwYc9AeWirMVRDi+WYlsktzAEObiFoPqs+LWU5q7+Q1+nEcs
tNuDIedeBRcHmtjL2hV3luuEWwDSnRhSjhPLPXzqpJ1rG3r4yqm1NjKg5A5QO9Az
veHqRQldluTSKuu96oPEPusL2oF+4MxkJ+SQMGFWTw/PNCblUN8GXeL5+mR20diP
5LiJMq8U3IpM/0Q7OFFQ+lXuYFIuDvUprWBPsp5La2WhL2+iLVVXItSl7up5yQqX
XftzTXTX48FRiJ6PA9o=
-----END CERTIFICATE-----""",
    # Gekwalificeerd (eIDAS): dienstcertificaat "GLOBALTRUST 2015 QUALIFIED TIMESTAMP 1" zoals op de Oostenrijkse
    # vertrouwenslijst (status granted sinds 2018-09-18; SHA-256 945522340e54b7f2…7b0e0883fc9)
    "GLOBALTRUST 2015 QUALIFIED TIMESTAMP 1": """-----BEGIN CERTIFICATE-----
MIIHXTCCBUWgAwIBAgINAYTZxJjBeQOJSySNVTANBgkqhkiG9w0BAQsFADCBlzEL
MAkGA1UEBhMCQVQxDTALBgNVBAgTBFdpZW4xDTALBgNVBAcTBFdpZW4xIzAhBgNV
BAoTGmUtY29tbWVyY2UgbW9uaXRvcmluZyBHbWJIMSowKAYDVQQLEyFHTE9CQUxU
UlVTVCBDZXJ0aWZpY2F0aW9uIFNlcnZpY2UxGTAXBgNVBAMTEEdMT0JBTFRSVVNU
IDIwMTUwHhcNMTUwNjI2MDAwMDAwWhcNNDAwNjEwMDAwMDAwWjCBrTELMAkGA1UE
BhMCQVQxDTALBgNVBAgTBFdpZW4xDTALBgNVBAcTBFdpZW4xIzAhBgNVBAoTGmUt
Y29tbWVyY2UgbW9uaXRvcmluZyBHbWJIMSowKAYDVQQLEyFHTE9CQUxUUlVTVCBD
ZXJ0aWZpY2F0aW9uIFNlcnZpY2UxLzAtBgNVBAMTJkdMT0JBTFRSVVNUIDIwMTUg
UVVBTElGSUVEIFRJTUVTVEFNUCAxMIICIDANBgkqhkiG9w0BAQEFAAOCAg0AMIIC
CAKCAgEAwKrjt+qz1VUUllgI15FfMWXvsHjbykfi6JZfuE1AzSd//ROkoxPUfcHv
ZBDfPQEvINlHw7ZLV2rZElN64/fmCLlHKevk1hJ+0SkVRrSAydLLOmUPrYzHRyzV
AsBbsSBPRshmSDYNW4iEofkHWCzvtyZ0AK43gasXWe8cSU+cBURqwXVi0tyfhmCn
LBd7AvBhEXoYxUK54CsRgWmKhwriZRdnRHcVHY+fy0902KGkrnzsGoZDwu5a4+qz
yaM6L+WAHfqSlMY/ag3plYmkO6Dri63gBfI2lIQAJoANga7y00YAUwPvDVgVnSwl
Er6SkOWEyBeofXNXKr7S8lhMWCFMwyog1Cw/QbPUSGD0AwXjWoJTBXtEBXc4OyJQ
CbsbhCNP5HSosN62YV1vgXl19OaJxFThPEsXIipvpf1tqYgRLGUzK6iXhbHhVaHR
v+VCJdAYd1OBCX7Rcfn2vil/OTThAzCNmjH3ocYR7Kucert8d7u4xjSoXTF76rWb
53DlQKxy44L3grJWaY2P2n+tBb12KcpGAHx4d6gmhyt6pM8opLAQr+LFCv7mT65i
XcDHygGaumYjPXuu/Bi2uJonM7FPgrg5OMGStbY0JHKhC4bHWLVEECFL29bMjynk
ZeSG29KG7CARfH/1Yp7PK629fZhpDj+jMmur0Al6+lUunnULJycCAQOjggGQMIIB
jDASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4EFgQU
8jsx5Q3SC9mBeVB1vWJQ5pHKg78wHwYDVR0jBBgwFoAUy7DdPYw832IsK2Y8njzp
FW1xtNcwgYEGCCsGAQUFBwEBBHUwczAmBggrBgEFBQcwAYYaaHR0cDovL29jc3Au
Z2xvYmFsdHJ1c3QuZXUwSQYIKwYBBQUHMAKGPWh0dHA6Ly9zZXJ2aWNlLmdsb2Jh
bHRydXN0LmV1L3N0YXRpYy9nbG9iYWx0cnVzdC0yMDE1LWRlci5jZXIwSgYDVR0f
BEMwQTA/oD2gO4Y5aHR0cDovL3NlcnZpY2UuZ2xvYmFsdHJ1c3QuZXUvc3RhdGlj
L2dsb2JhbHRydXN0LTIwMTUuY3JsMFYGA1UdIARPME0wSwYIKigAJAEBCAEwPzA9
BggrBgEFBQcCARYxaHR0cDovL3d3dy5nbG9iYWx0cnVzdC5ldS9jZXJ0aWZpY2F0
ZS1wb2xpY3kuaHRtbDANBgkqhkiG9w0BAQsFAAOCAgEAzFFMTO9LcPJyV5yprCvd
eFUK2kSldYCZR9QdRhOdXeKuQrLuHnOitMWmdK1CdMzQNJgCRo6Frwe7wB777nt4
nYlfYDcFU8FPGh3C70n9aqOHI5UyURE8rtbJANtRZfqxm/2mPbJod15j0+xg0zby
MB47WTaMETx8RvBlAGx9wrYmwIZMC/57DCR+5MiEBOoXtYJ91dbUUfUfKRkFTit+
1OEp/hHjGdh8f7dt80XMFplJF3lFrO3ADqdW0OfP44V8Mfy7a/339Z36+g2ZOWZx
ZYhm5smpidg1wCSvAYitWENcOq/qihOoaOSR7aQ1e/iCj1QGdE12m8kz4Smjz5ud
04RUL1DJinoqGmYSrVlJrdLdXoQRl1toUKXVhCd47lzRW5hNF1orgqwnpf7eh/eJ
kSVHw5zTJ/ZU7UT7ZfE2WMmsZETgBRlLX4vyMa2TGkjNrkPgW/AAY6Tv/0/vyzih
0LDNrjzvRdFfROAkfSqyxEix1/dDjWKcRbJmCgKxVnzGurLQ6d7rludguYb3hMAN
2fs1uVH+SR1B/vWPFVtRY0mKQdNItLrWd0Ju33tUEg8Ck9H5gZOhdx7nJTTsaYbP
9KECb+bVnWIVxy6yafA3otRd4dwohW4sUJnWzzphyDIQyl4CHSXencA9+JSCKWZQ
aQK3mQ7dC7CeChacfVC+Sic=
-----END CERTIFICATE-----""",
}
ANKERS_STANDAARD = ("Sectigo Public Time Stamping Root R46", "GLOBALTRUST 2015 QUALIFIED TIMESTAMP 1")
ANKERS_GEKWALIFICEERD = ("GLOBALTRUST 2015 QUALIFIED TIMESTAMP 1",)   # eIDAS: alleen de dienst op de vertrouwenslijst

# 13/10/2026 (studie bewijsvoering §5.1, B1): de woorden voor mensen. Bewust een kopie van webapp/merk/statuswoorden.js, want dit
# script moet zelfstandig blijven (geen Vidimus-code). tests/test_bewijs_eerlijk.py bewaakt dat elk woord gelijk is aan het
# woordenboek, op drie overbruggingen na tot het woordenboek ze heeft: kop 'geregistreerd' (B1: "inhoud hier niet nagerekend"),
# kop 'herkomst-niet-vastgesteld' en reden 'zout-ontbreekt'.
_WOORDEN = {
    "kop": {
        "ongewijzigd": "ongewijzigd",
        "geregistreerd": "inhoud hier niet nagerekend",
        "gewijzigd": "gewijzigd",
        "een-wijkt-af": "één controle wijkt af",
        "n-wijken-af": "{n} controles wijken af",
        "niet-volledig": "niet volledig nagerekend",
        "herkomst-niet-vastgesteld": "herkomst niet vastgesteld",
    },
    "uitkomst": {"stemt-overeen": "stemt overeen", "volgt": "volgt", "niet-nagerekend": "niet nagerekend", "wijkt-af": "wijkt af"},
    "redenen": {
        "versleuteld": "ze is versleuteld",
        "gewist": "ze is gewist",
        "bundel-onvolledig": "niet elke bijlage zat in de bundel",
        "offline": "u bent offline",
        "vreemde-sleutels": "de sleutels in deze bundel zijn niet die van Vidimus",
        "zout-ontbreekt": "het zout zit niet in deze bundel",
    },
    "termijnen": {"bitcoin": "meestal binnen 1 tot 6 uur"},
}
# Redenen die (nog) niet in het woordenboek staan: alleen voor de uitvoer van dit script, met de controle erbij.
_REDENEN_SCRIPT = {
    "geen-inhoud": "registration.json zit niet in de bundel",
    "geen-token": "geen tijdstempel in deze bundel",
    "token-ontbreekt": "het token zit niet in de bundel",
    "bewijs-ontbreekt": "bitcoin.ots zit niet in de bundel",
    "record-ontbreekt": "het logboekrecord zit niet in de bundel",
    "geen-anker": "leidt niet naar een vastgepind anker",
    "handtekening-onleesbaar": "de handtekening van de dienst is hier niet na te rekenen",
    "wacht-op-blok": "wacht op een Bitcoin-blok",
    "buiten-de-bundel": "na te kijken bij een peer van het kanaal",
}
_BIBLIOTHEEK = {"tsa": "rfc3161ng ontbreekt", "qualified_tsa": "rfc3161ng ontbreekt", "bitcoin": "opentimestamps-client ontbreekt"}
_NAMEN = {"hash": "inhoud", "merkle": "groep", "signature": "handtekening van de indiener", "platform_signature": "handtekening van Vidimus over de bundel",
          "ledger": "logboek", "tsa": "tijdstempel", "qualified_tsa": "gekwalificeerde tijdstempel", "bitcoin": "Bitcoin-blok",
          "fabric": "gedeeld logboek (Fabric)", "counter_signature": "handtekening van de tegenpartij"}
_GETUIGEN = ("tsa", "qualified_tsa", "bitcoin")
_INTEGRITEIT = ("signature", "platform_signature", "merkle")


def kop_bewijs(checks: dict, herkomst: dict) -> dict:
    """De kop van de hele registratie (studie §5.1), in deze volgorde: gewijzigd · één/n controle(s) wijken af · herkomst niet
    vastgesteld · niet volledig nagerekend · inhoud hier niet nagerekend · ongewijzigd. Zelfde regels als statuswoorden.kop(),
    met de herkomst als eigen kop (B1)."""
    c = dict(checks or {}); hk = herkomst or {}
    w = _WOORDEN["kop"]
    uit = lambda sleutel, lijst=(), **x: {"sleutel": sleutel, "woord": w[sleutel].replace("{n}", str(x.get("n", ""))), "afwijkend": list(lijst)}
    if c.get("hash") is False:
        return uit("gewijzigd", ["hash"])
    afwijkend = sorted(k for k, v in c.items() if k != "hash" and v is False)
    if len(afwijkend) == 1:
        return uit("een-wijkt-af", afwijkend)
    if afwijkend:
        return uit("n-wijken-af", afwijkend, n=len(afwijkend))
    if not hk.get("ca") or not hk.get("platform"):
        return uit("herkomst-niet-vastgesteld")
    if not any(c.get(k) is True for k in _GETUIGEN) or not all(c.get(k) is True for k in _INTEGRITEIT):
        return uit("niet-volledig")
    if c.get("hash") is not True:
        return uit("geregistreerd")
    return uit("ongewijzigd")


def telling(checks: dict, details: dict = None) -> dict:
    """Eén telling (studie §5.1 'Tellen'): de noemer is alle controles; Bitcoin zonder blok 'volgt nog', elke andere null is
    'niet nagerekend'."""
    btc_blok = ((details or {}).get("bitcoin") or {}).get("block_height")
    t = {"totaal": len(checks), "overeen": 0, "volgt": 0, "niet": 0, "af": 0}
    for k, v in checks.items():
        if v is True: t["overeen"] += 1
        elif v is False: t["af"] += 1
        elif k == "bitcoin" and not btc_blok: t["volgt"] += 1
        else: t["niet"] += 1
    return t


def _telling_tekst(t: dict) -> str:
    deel = [f"{t['overeen']} van {t['totaal']} controles stemmen overeen"]
    if t["volgt"]: deel.append(f"{t['volgt']} {'volgt' if t['volgt'] == 1 else 'volgen'} nog")
    if t["af"]: deel.append(f"{t['af']} {'wijkt' if t['af'] == 1 else 'wijken'} af")
    if t["niet"]: deel.append(f"{t['niet']} niet nagerekend")
    return " · ".join(deel)


# 13/10/2026 (review M3): de sleutel 'offline' blijft (woordenboek, /v), maar wie hier rekent, is niet altijd offline: ook een
# storing of een weigering van de blockexplorer geeft deze sleutel. Het script en het dossier zeggen daarom wat er gebeurde.
_REDENEN_FEIT = {"offline": "de blockexplorer (blockstream.info) gaf geen bruikbaar antwoord"}


def reden_tekst(controle: str, sleutel: str) -> str:
    if sleutel in _REDENEN_FEIT:
        return _REDENEN_FEIT[sleutel]
    if sleutel == "bibliotheek-ontbreekt":
        return _BIBLIOTHEEK.get(controle, "een Python-bibliotheek ontbreekt (zie notes)")
    return _WOORDEN["redenen"].get(sleutel) or _REDENEN_SCRIPT.get(sleutel) or sleutel


def canon_bytes(obj) -> bytes:
    def chk(o):
        if isinstance(o, float) and not math.isfinite(o):
            raise ValueError("NaN")
        if isinstance(o, dict):
            [chk(v) for v in o.values()]
        elif isinstance(o, list):
            [chk(v) for v in o]
    chk(obj)
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode()


def _parent(a, b):
    lo, hi = sorted((a, b))
    return hashlib.sha256(bytes.fromhex(lo) + bytes.fromhex(hi)).hexdigest()


def merkle_verify(leaf, path, root):
    h = leaf
    for s in path:
        h = _parent(h, s)
    return h == root


def _ed_verify(public_pem: str, data: bytes, sig: bytes) -> bool:
    from cryptography.hazmat.primitives import serialization
    from cryptography.exceptions import InvalidSignature
    pub = serialization.load_pem_public_key(public_pem.encode())
    try:
        pub.verify(sig, data)
        return True
    except InvalidSignature:
        return False


def _cert_pub_pem_and_chain(cert_pem: str, ca_pem: str):
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization
    from cryptography.exceptions import InvalidSignature
    c = x509.load_pem_x509_certificate(cert_pem.encode())
    ca = x509.load_pem_x509_certificate(ca_pem.encode())
    pub_pem = c.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo).decode()
    try:
        ca.public_key().verify(c.signature, c.tbs_certificate_bytes)
        chain = c.issuer == ca.subject
    except InvalidSignature:
        chain = False
    return pub_pem, chain


def _keten_via_tussen_ca(cert_pem: str, ica_pem: str, root_pem: str):
    """06/10/2026: ondertekenaar → tussen-CA → hoofd-CA. De tussen-CA moet een CA zijn die eindcertificaten mag uitgeven
    (basicConstraints, keyCertSign), getekend door de hoofd-CA, en de hoofd-CA moet een tussen-CA mogen hebben (padlengte ≥ 1)."""
    from cryptography import x509
    pub_pem, onder_ica = _cert_pub_pem_and_chain(cert_pem, ica_pem)
    _, ica_onder_root = _cert_pub_pem_and_chain(ica_pem, root_pem)
    ica, root = x509.load_pem_x509_certificate(ica_pem.encode()), x509.load_pem_x509_certificate(root_pem.encode())
    return pub_pem, bool(onder_ica and ica_onder_root and _mag_uitgeven(ica, 0) and _mag_uitgeven(root, 1))


def _tussen_ca_geldig(ica_pem: str, moment) -> str:
    """Leeg als de tussen-CA geldig was op het moment van tekenen, anders de reden."""
    from cryptography import x509
    m = _iso(moment)
    if m and not _geldig_op(x509.load_pem_x509_certificate(ica_pem.encode()), m):
        return f"de tussen-CA viel op het moment van tekenen buiten haar geldigheidsperiode ({moment})"
    return ""


def _bevestiging_tekst(b):
    if not b: return None
    if b.get("via") == "enclave": return "Face ID / pincode op het toestel (Secure Enclave, gebruiker geverifieerd)"
    if b.get("via") == "passkey" and b.get("biometrie"): return "Face ID / vingerafdruk op het toestel (passkey, gebruiker geverifieerd)"
    if b.get("via") == "passkey": return "toestelsleutel; passkey aanwezig maar offline getekend (wachtrij)"
    return "toestelsleutel zonder biometrie"

def _tst_serial(token_b64) -> str:
    """Serienummer van het tijdstempel zelf (TSTInfo.serialNumber), zoals `openssl ts -text` het toont.
    Het veld 'serial' dat timestamp.py bewaart is het serienummer van het ondertekenaarscertificaat, niet van het token."""
    if not token_b64: return ""
    try:
        from pyasn1.codec.der import decoder
        import rfc3161ng
        t, _ = decoder.decode(base64.b64decode(token_b64), asn1Spec=rfc3161ng.TimeStampToken())
        return format(int(t.tst_info["serialNumber"]), "X")
    except Exception:
        return ""

_BTC_CACHE = {}               # {hoogte: (merkle_root, bloktijd, opgehaald_op)}: een blok verandert niet meer
_BTC_CACHE_MAX = 512
_BTC_CACHE_SECONDEN = 3600
_BTC_SLOT = threading.Lock()


def _blok_ophalen(hoogte: int):
    """(merkle_root, bloktijd in Unix-seconden) van blok `hoogte` volgens blockstream.info. Een fout gaat naar de aanroeper."""
    import urllib.request
    h = urllib.request.urlopen(f"https://blockstream.info/api/block-height/{hoogte}", timeout=8).read().decode().strip()
    info = json.loads(urllib.request.urlopen(f"https://blockstream.info/api/block/{h}", timeout=8).read().decode())
    if not isinstance(info, dict) or not info.get("merkle_root"):
        raise ValueError("antwoord zonder merkle-wortel")   # niet in de cache, niet als afwijking
    return info.get("merkle_root"), info.get("timestamp")


def _blok(hoogte: int):
    """13/10/2026: één opvraging per blokhoogte per uur (de server rekent bij elke /verify en elke /v). Alleen een geslaagd
    antwoord gaat in de cache. Geeft (merkle_root, bloktijd, uit_cache_van)."""
    nu = time.time()
    with _BTC_SLOT:
        c = _BTC_CACHE.get(hoogte)
        if c and nu - c[2] < _BTC_CACHE_SECONDEN:
            return c[0], c[1], c[2]
    root, tijd = _blok_ophalen(hoogte)
    with _BTC_SLOT:
        if len(_BTC_CACHE) >= _BTC_CACHE_MAX:
            _BTC_CACHE.pop(min(_BTC_CACHE, key=lambda k: _BTC_CACHE[k][2]), None)
        _BTC_CACHE[hoogte] = (root, tijd, nu)
    return root, tijd, None


def _bitcoin_bewijs(ots: bytes, root_hex: str, hoogte: int):
    """(True/False/None, uitleg, reden). Rekent het OpenTimestamps-bewijs na: begint het bij de batchwortel, leidt het naar een
    Bitcoin-blok, en (online) is de Merkle-wortel in dat bewijs dezelfde als die van het blok volgens blockstream.info?"""
    try:
        from opentimestamps.core.timestamp import DetachedTimestampFile
        from opentimestamps.core.notary import BitcoinBlockHeaderAttestation
        from opentimestamps.core.serialize import BytesDeserializationContext
    except ImportError:
        return None, "bewijsbestand aanwezig; installeer 'opentimestamps-client' (pip) om het na te rekenen, of: ots --no-bitcoin verify -d <merkle.root> bitcoin.ots en de blok-merkle-wortel in een blockexplorer vergelijken", "bibliotheek-ontbreekt"
    try:
        d = DetachedTimestampFile.deserialize(BytesDeserializationContext(ots))
    except Exception as e:
        return False, f"bitcoin.ots is geen leesbaar OpenTimestamps-bestand ({e.__class__.__name__})", None
    if root_hex and d.timestamp.msg.hex() != root_hex.lower():
        return False, "het bewijs begint niet bij de batchwortel uit het manifest", None
    blokken = {}
    for msg, att in d.timestamp.all_attestations():
        if isinstance(att, BitcoinBlockHeaderAttestation): blokken[att.height] = msg   # msg = merkle-wortel van het blok (little-endian)
    if not blokken:
        return None, "bewijs bevat nog geen Bitcoin-blok (wacht op bevestiging; bundel later opnieuw downloaden)", "wacht-op-blok"
    if hoogte not in blokken:
        return False, f"manifest zegt blok {hoogte}, bewijs wijst naar blok {sorted(blokken)}", None
    verwacht = blokken[hoogte][::-1].hex()
    try:
        blok_root, blok_tijd, uit_cache = _blok(hoogte)
    except Exception:
        # 05/10/2026: zonder vergelijking met het echte blok is een .ots-bestand niet meer dan een bewering → niet als tijdsgetuige tellen
        return None, f"pad van batchwortel naar Bitcoin-blok {hoogte} stemt overeen, maar blockstream.info gaf geen bruikbaar antwoord: blokinhoud niet vergeleken (vergelijk merkle-wortel {verwacht} op twee explorers)", "offline"
    bron = "blockstream.info" + (f", uit de cache van {datetime.fromtimestamp(uit_cache, tz=timezone.utc).isoformat(timespec='seconds')}" if uit_cache else "")
    if blok_root == verwacht:
        return True, f"pad van batchwortel naar Bitcoin-blok {hoogte} stemt overeen; merkle-wortel van het blok vergeleken met {bron} ({blok_tijd and datetime.fromtimestamp(blok_tijd, tz=timezone.utc).isoformat()})", None
    return False, f"blok {hoogte}: merkle-wortel in het bewijs ({verwacht[:16]}…) verschilt van {bron} ({str(blok_root)[:16]}…)", None

def _ankers(namen=None) -> list:
    from cryptography import x509
    return [x509.load_pem_x509_certificate(TSA_ANKERS_PEM[n].encode()) for n in (namen or TSA_ANKERS_PEM)]


def _uitgegeven_door(cert, uitgever) -> bool:
    """Is `cert` ondertekend door de sleutel van `uitgever` (en klopt de naam)?"""
    if cert.issuer != uitgever.subject:
        return False
    try:
        cert.verify_directly_issued_by(uitgever)
        return True
    except AttributeError:   # cryptography < 40
        from cryptography.hazmat.primitives.asymmetric import ec, padding, rsa
        pub = uitgever.public_key()
        try:
            if isinstance(pub, rsa.RSAPublicKey):
                pub.verify(cert.signature, cert.tbs_certificate_bytes, padding.PKCS1v15(), cert.signature_hash_algorithm)
            elif isinstance(pub, ec.EllipticCurvePublicKey):
                pub.verify(cert.signature, cert.tbs_certificate_bytes, ec.ECDSA(cert.signature_hash_algorithm))
            else:
                pub.verify(cert.signature, cert.tbs_certificate_bytes)
            return True
        except Exception:
            return False
    except Exception:
        return False


def _geldig_op(cert, moment) -> bool:
    voor = getattr(cert, "not_valid_before_utc", None) or cert.not_valid_before.replace(tzinfo=timezone.utc)   # cryptography < 42
    na = getattr(cert, "not_valid_after_utc", None) or cert.not_valid_after.replace(tzinfo=timezone.utc)
    return voor <= moment <= na


def _mag_uitgeven(c, onder: int) -> bool:
    """Mag `c` een certificaat in een tijdstempelketen uitgeven? CA (basicConstraints), padlengte ruim genoeg voor de `onder`
    CA-certificaten eronder, keyCertSign als keyUsage er staat, en een eventuele EKU laat timeStamping toe. Zo kan een gewoon
    webcertificaat, of een CA die alleen voor websites mag tekenen, geen 'tijdstempeldienst' in het leven roepen."""
    from cryptography import x509
    from cryptography.x509.oid import ExtendedKeyUsageOID
    try:
        bc = c.extensions.get_extension_for_class(x509.BasicConstraints).value
    except x509.ExtensionNotFound:
        return False
    if not bc.ca or (bc.path_length is not None and onder > bc.path_length):
        return False
    try:
        if not c.extensions.get_extension_for_class(x509.KeyUsage).value.key_cert_sign:
            return False
    except x509.ExtensionNotFound:
        pass
    try:
        eku = c.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
        if ExtendedKeyUsageOID.TIME_STAMPING not in eku and ExtendedKeyUsageOID.ANY_EXTENDED_KEY_USAGE not in eku:
            return False
    except x509.ExtensionNotFound:
        pass
    return True


def _keten_naar_anker(cert, tussen: list, ankers: list, moment):
    """Naam van het vastgepinde anker waar `cert` via de certificaten `tussen` naartoe leidt, anders None. Elk certificaat moet
    geldig zijn op `moment` en elke uitgever moet mogen uitgeven (_mag_uitgeven). Alleen de ankers tellen: een certificaat met
    dezelfde naam maar een andere sleutel leidt nergens heen."""
    from cryptography.hazmat.primitives import hashes
    try:
        vingers = {a.fingerprint(hashes.SHA256()) for a in ankers}
        huidig, gezien, onder = cert, set(), 0
        for _ in range(8):
            if not _geldig_op(huidig, moment):
                return None
            vinger = huidig.fingerprint(hashes.SHA256())
            if huidig is not cert and vinger in vingers:
                return huidig.subject.rfc4514_string()
            gezien.add(vinger)
            for a in ankers:
                if _uitgegeven_door(huidig, a) and _geldig_op(a, moment) and _mag_uitgeven(a, onder):
                    return a.subject.rfc4514_string()
            volgende = next((c for c in tussen if c.fingerprint(hashes.SHA256()) not in gezien
                             and _uitgegeven_door(huidig, c) and _mag_uitgeven(c, onder)), None)
            if volgende is None:
                return None
            huidig, onder = volgende, onder + 1
    except Exception:
        return None
    return None


def _is_tsa_cert(cert) -> bool:
    from cryptography import x509
    from cryptography.x509.oid import ExtendedKeyUsageOID
    try:
        return ExtendedKeyUsageOID.TIME_STAMPING in cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
    except x509.ExtensionNotFound:
        return False


def _token_geldig(token_b64: str, digest_hex: str, label: str, notes: list, ankers=ANKERS_STANDAARD, uit=None):
    """RFC 3161-token controleren voor deze digest. True alleen als (1) messageImprint = digest, (2) de handtekening klopt met een
    tijdstempelcertificaat (EKU timeStamping) uit het token, en (3) dat certificaat op het tijdstempelmoment via een keten naar een
    van de vastgepinde `ankers` van dit slot leidt. False alleen als het token aantoonbaar over iets anders gaat (andere digest) of
    onleesbaar is; None als het niet na te rekenen is (ontbrekende bibliotheek, certificaat of algoritme) of niet naar een anker
    leidt — dan geen fout, maar ook geen tijdsgetuige."""
    try:
        import rfc3161ng
        from cryptography import x509
        from pyasn1.codec.der import decoder as _dec, encoder as _enc
        from pyasn1_modules import rfc2315 as _cms
    except ImportError:
        notes.append(f"{label}: token aanwezig; installeer 'rfc3161ng' om het na te rekenen")
        if uit is not None: uit["reden"] = "bibliotheek-ontbreekt"
        return None
    try:
        token = base64.b64decode(token_b64)
        ci, _ = _dec.decode(token, asn1Spec=_cms.ContentInfo())
        sd, _ = _dec.decode(ci["content"], asn1Spec=_cms.SignedData())
        certs = [x509.load_der_x509_certificate(_enc.encode(c["certificate"])) for c in (sd["certificates"] if sd["certificates"].isValue else [])]
        tst, _ = _dec.decode(token, asn1Spec=rfc3161ng.TimeStampToken())
        imprint = bytes(tst.tst_info["messageImprint"]["hashedMessage"]).hex()
        moment = rfc3161ng.get_timestamp(token)
        if moment.tzinfo is None:
            moment = moment.replace(tzinfo=timezone.utc)
    except Exception as e:
        notes.append(f"{label}: geen leesbaar RFC 3161-token ({e.__class__.__name__})"); return False
    if imprint != digest_hex.lower():
        notes.append(f"{label}: het token stempelt een andere vingerafdruk ({imprint[:16]}…) dan deze wortel"); return False
    getekend = None
    for c in certs:
        try:
            if _is_tsa_cert(c) and rfc3161ng.check_timestamp(token, certificate=c.public_bytes(_der()), digest=bytes.fromhex(digest_hex), hashname="sha256"):
                getekend = c; break
        except Exception:
            continue
    if getekend is None:
        notes.append(f"{label}: handtekening niet na te rekenen met een tijdstempelcertificaat uit het token (ontbreekt, ander algoritme of "
                     "past niet) — tijd niet onafhankelijk vastgesteld")
        if uit is not None: uit["reden"] = "handtekening-onleesbaar"
        return None
    anker = _keten_naar_anker(getekend, certs, _ankers(ankers), moment)
    if not anker:
        notes.append(f"{label}: token stemt overeen, maar '{getekend.subject.rfc4514_string()}' leidt niet naar een vastgepind anker voor dit slot "
                     f"({' of '.join(ankers)}) — tijd niet onafhankelijk vastgesteld")
        if uit is not None: uit["reden"] = "geen-anker"
        return None
    notes.append(f"{label}: getekend door {getekend.subject.rfc4514_string()} op {moment.isoformat()}, keten naar {anker}")
    if uit is not None: uit["moment"] = moment   # het nagerekende tijdstip (genTime), niet wat het manifest zegt
    return True


def _laatste(notes: list, prefix: str) -> str:
    """De laatste note met dit voorvoegsel, zonder het voorvoegsel: de zin bij een afwijkende controle."""
    for n in reversed(notes):
        if n.startswith(prefix):
            return n[len(prefix):]
    return ""


def _iso(t):
    try:
        d = datetime.fromisoformat(str(t).replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=timezone.utc)
    except Exception:
        return None


def _tijd_klopt(claim, geverifieerd, label: str, notes: list) -> bool:
    """05/10/2026: getoond wordt altijd de tijd uit het nagerekende token. Noemt het manifest een andere tijd, dan melden we dat
    (oude batches bewaarden soms lokale tijd als UTC); het bewijs zelf hangt aan het token, niet aan die regel in het manifest."""
    c = _iso(claim)
    if c is None or abs((c - geverifieerd).total_seconds()) > 1:
        notes.append(f"{label}: het manifest noemt {claim}, het token zelf {geverifieerd.isoformat()} — getoond wordt de tijd van het token")
        return False
    return True


def _der():
    from cryptography.hazmat.primitives import serialization
    return serialization.Encoding.DER


def _signer_binding(cert_pem: str, signer: dict, created):
    """Leeg als het certificaat bij de ondertekenaar in het manifest hoort en geldig was op het moment van tekenen, anders de reden."""
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    c = x509.load_pem_x509_certificate(cert_pem.encode())
    cn = c.subject.get_attributes_for_oid(NameOID.COMMON_NAME)
    cn = cn[0].value if cn else ""
    if signer.get("subject_cn") is not None and signer.get("subject_cn") != cn:
        return f"het manifest noemt '{signer.get('subject_cn')}' als ondertekenaar, het certificaat '{cn}'"
    if created:
        try:
            moment = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
            if moment.tzinfo is None:
                moment = moment.replace(tzinfo=timezone.utc)
            if not _geldig_op(c, moment):
                return f"het certificaat van de ondertekenaar viel op het moment van tekenen buiten zijn geldigheidsperiode ({created})"
        except ValueError:
            pass
    return ""


def _ca_vingerafdruk(ca_pem: str):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    try:
        return x509.load_pem_x509_certificate(ca_pem.encode()).fingerprint(hashes.SHA256()).hex()
    except Exception:
        return None


def _inhoud(z, names: set, m: dict, notes: list):
    """Stap 1: de vingerafdruk van inhoud en bijlagen herrekenen. Geeft (True/False/None, reden bij None, afwijking bij False).
    13/10/2026: een versleutelde bijlage (laag B) is hier niet nagerekend: null met reden 'versleuteld', nooit 'stemt overeen'.
    Wijkt de vingerafdruk af, dan noemt het script de bijlage(n) die afwijken, of registration.json als geen bijlage afwijkt."""
    reg = m["registration"]
    if "registration.json" not in names:
        if reg.get("shredded"):
            d = _iso(reg.get("shredded"))
            notes.append("inhoud: gewist" + (f" op {d.date().isoformat()}" if d else "") + "; de vingerafdruk van toen blijft verankerd, de inhoud is hier niet nagerekend")
            return None, "gewist", None
        notes.append("inhoud: registration.json zit niet in de bundel; de inhoud is hier niet nagerekend")
        return None, "geen-inhoud", None
    payload = json.loads(z.read("registration.json"))
    att_hashes, eigen = {}, {}
    ontbreekt, versleuteld = [], []
    enc = m.get("encrypted_attachments") or {}
    for name in reg.get("attachments", {}):
        fn = f"attachments/{name}"
        if name in enc:   # op het toestel versleuteld: de bundel bevat cijfertekst; de verankerde vingerafdruk is die van het origineel
            att_hashes[name] = reg["attachments"][name]; versleuteld.append(name)
            notes.append(f"bijlage {name}: op het toestel versleuteld; de vingerafdruk van het origineel is verankerd, de bijlage zelf is hier "
                         "niet nagerekend (ontsleutel met --herstel)")
        elif fn in names:
            att_hashes[name] = eigen[name] = hashlib.sha256(z.read(fn)).hexdigest()
        else:
            att_hashes[name] = reg["attachments"][name]; ontbreekt.append(name)
            notes.append(f"bijlage {name} zit niet in de bundel")
    digest_input = {"canon": m["canon"], "payload": payload, "attachments": att_hashes}
    if m.get("canon") != CANON_V1:   # canon v2: het organisatiekenmerk van het registratiemoment (manifest.registration.org_kenmerk)
        digest_input["org"] = reg.get("org_kenmerk") or ((m.get("organisatie") or {}).get("kenmerk")) or ""
    if m.get("canon") == CANON_V3:   # canon v3: het geheime zout van deze registratie zit in de invoer (manifest.disclosure.salt)
        zout = (m.get("disclosure") or {}).get("salt")
        if not zout:
            notes.append("gezouten vingerafdruk (persoonsgegevens): het zout van deze registratie zit niet in de bundel; inhoud hier niet nagerekend")
            return None, "zout-ontbreekt", None
        digest_input["salt"] = zout
    data = canon_bytes(digest_input)
    if reg["hash_type"] == "sha256":
        calc = hashlib.sha256(data).hexdigest()
    elif reg["hash_type"] == "hmac-sha256":
        salt_hex = (m.get("disclosure") or {}).get("salt")
        if not salt_hex:
            notes.append("gesleutelde vingerafdruk: de salt is niet meegeleverd (bewust, AVG); inhoud hier niet nagerekend")
            return None, "zout-ontbreekt", None
        calc = hmac.new(bytes.fromhex(salt_hex), data, hashlib.sha256).hexdigest()
    else:
        notes.append(f"inhoud: onbekend soort vingerafdruk ({reg.get('hash_type')})")
        return None, "geen-inhoud", None
    if calc != reg["hash"]:
        anders = sorted(n for n, h in eigen.items() if h != reg["attachments"].get(n))
        for n in anders:
            notes.append(f"inhoud: bijlage {n} wijkt af (vingerafdruk {eigen[n][:16]}…, verankerd {str(reg['attachments'].get(n))[:16]}…)")
        if anders:
            return False, None, "inhoud · " + ", ".join(anders)
        notes.append("inhoud: de bijlagen in de bundel stemmen overeen; de afwijking zit in registration.json (de gegevens) of in wat het "
                     "manifest over deze registratie zegt (vingerafdruk, organisatiekenmerk of zout). Welk veld, kan het script niet zeggen: "
                     "het manifest bevat alleen de vingerafdruk van het geheel")
        return False, None, "inhoud · registration.json (de gegevens) of de vingerafdruk in manifest.json"
    if ontbreekt:   # 05/10: niet elke bijlage zat erin → niet 'nagerekend'
        notes.append("inhoud: de gegevens stemmen overeen, maar niet elke bijlage zat in de bundel — inhoud niet volledig nagerekend")
        return None, "bundel-onvolledig", None
    if versleuteld:
        return None, "versleuteld", None
    return True, None, None


def verify_bundle(path, vertrouwde_ca=(), vertrouwd_platform=()) -> dict:
    """`vertrouwde_ca` / `vertrouwd_platform`: extra SHA-256-vingerafdrukken van een CA- en platformcertificaat die de aanroeper
    vertrouwt naast de gepubliceerde (bv. de server die zijn eigen bundels narekent). Een deskundige laat ze leeg."""
    checks = {"hash": None, "merkle": None, "signature": None, "platform_signature": None, "ledger": None, "tsa": None}
    notes = []; redenen = {}; afwijking = {}
    platform_vinger = gewist_op = None
    with zipfile.ZipFile(path) as z:
        totaal = 0
        for info in z.infolist():   # zipbom: niets uitpakken dat onredelijk groot is
            totaal += info.file_size
            if info.file_size > MAX_LID_BYTES or totaal > MAX_TOTAAL_BYTES:
                raise ValueError(f"bundel te groot om veilig na te rekenen ({info.filename}: {info.file_size} bytes uitgepakt)")
        names = set(z.namelist())
        manifest_raw = z.read("manifest.json")
        m = json.loads(manifest_raw)
        ots_bytes = z.read("bitcoin.ots") if "bitcoin.ots" in names else None
        org_ca_pem = z.read("org-ca.pem").decode() if "org-ca.pem" in names else None
        ica_pem = z.read("org-ica.pem").decode() if "org-ica.pem" in names else None   # 06/10/2026: tussen-CA (hoofd-CA offline)

        # 4. platform-handtekening over manifest.json (exacte bytes)
        try:
            sig = z.read("manifest.sig")
            pcert = z.read("platform-cert.pem").decode()
            ca_pem = z.read("platform-ca.pem").decode() if "platform-ca.pem" in names else (org_ca_pem or pcert)
            ppub, pchain = _cert_pub_pem_and_chain(pcert, ca_pem)
            p_ed = _ed_verify(ppub, manifest_raw, sig)
            checks["platform_signature"] = p_ed and pchain
            platform_vinger = _ca_vingerafdruk(pcert)
            if not p_ed: afwijking["platform_signature"] = "de bundel is na het ondertekenen gewijzigd"
            elif not pchain: afwijking["platform_signature"] = "het platformcertificaat is niet uitgegeven door de CA in deze bundel"
        except Exception as e:
            checks["platform_signature"] = False; notes.append(f"platform: {e}")
            afwijking["platform_signature"] = "manifest.sig of platform-cert.pem ontbreekt of is onleesbaar"

        # 1. vingerafdruk herrekenen (registratie + bijlagen)
        reg = m["registration"]
        checks["hash"], reden, afw = _inhoud(z, names, m, notes)
        if reden: redenen["hash"] = reden
        if afw: afwijking["hash"] = afw
        if reden == "gewist" and _iso(reg.get("shredded")):
            gewist_op = _iso(reg.get("shredded")).date().isoformat()

        # 2. merkle
        mk = m["merkle"]
        checks["merkle"] = merkle_verify(reg["hash"], mk["path"], mk["root"])
        if not checks["merkle"]: afwijking["merkle"] = "de vingerafdruk hoort niet bij deze groep, dus het tijdstip is niet aangetoond"

        # 3. handtekening indiener over de hash
        teken_cert = teken_moment = None
        try:
            scert = z.read("signer-cert.pem").decode()
            ca_pem = org_ca_pem or scert
            spub, schain = _keten_via_tussen_ca(scert, ica_pem, ca_pem) if ica_pem else _cert_pub_pem_and_chain(scert, ca_pem)
            s_ed = _ed_verify(spub, bytes.fromhex(reg["hash"]), base64.b64decode(reg["signature_b64"]))
            checks["signature"] = s_ed and schain
            if not s_ed: afwijking["signature"] = "de handtekening hoort niet bij deze sleutel"
            elif not schain: afwijking["signature"] = "het certificaat van de indiener is niet uitgegeven door de CA in deze bundel"
            # 05/10: manifest-ondertekenaar = certificaat, geldig op het moment van tekenen (toestel: bevestiging.moment, later dan
            # 'created' als de registratie eerst klaargezet en daarna op een — eventueel nieuw — toestel getekend werd)
            getekend_op = [a.get("time") for a in (m.get("audit") or []) if isinstance(a, dict) and a.get("action") == "registration.sign"]
            moment = ((m.get("signer") or {}).get("bevestiging") or {}).get("moment") or (getekend_op[-1] if getekend_op else None) or reg.get("created")
            teken_cert, teken_moment = scert, moment
            binding = _signer_binding(scert, m.get("signer") or {}, moment) or (_tussen_ca_geldig(ica_pem, moment) if ica_pem else "")
            if binding:
                checks["signature"] = False; notes.append(f"signer: {binding}")
                afwijking["signature"] = ("de ondertekenaar in het manifest is niet die van het certificaat"   # zonder naam: afwijking is publiek
                                          if binding.startswith("het manifest noemt") else binding.split(" (")[0])
        except Exception as e:
            checks["signature"] = False; notes.append(f"signer: {e}")
            afwijking["signature"] = "signer-cert.pem ontbreekt of is onleesbaar"

        # 5. grootboek: tx_id = sha256(canon(index,prev,time,record)) en record.root == wortel
        lg = m.get("ledger")
        if lg and lg.get("record"):
            body = {k: lg["record"][k] for k in ("index", "prev", "time", "record")}
            calc = hashlib.sha256(canon_bytes(body)).hexdigest()
            checks["ledger"] = (calc == lg["tx_id"]) and lg["record"]["record"].get("root") == mk["root"]
            if not checks["ledger"]: afwijking["ledger"] = "het logboekrecord past niet bij zijn tx_id of bij deze groep"
        else:
            checks["ledger"] = None; redenen["ledger"] = "record-ontbreekt"; notes.append("logboekrecord niet meegeleverd (extern na te kijken via tx_id)")

        # 6. tsa
        ts = m.get("tsa", {}); tsa_uit = {}
        if ts.get("token_b64"):
            checks["tsa"] = _token_geldig(ts["token_b64"], mk["root"], "tsa", notes, uit=tsa_uit)
            if checks["tsa"] is True: _tijd_klopt(ts.get("time"), tsa_uit["moment"], "tsa", notes)
            elif checks["tsa"] is None: redenen["tsa"] = tsa_uit.get("reden") or "geen-anker"
            else: afwijking["tsa"] = _laatste(notes, "tsa: ") or "het token hoort niet bij deze groep"
        else:
            checks["tsa"] = None; redenen["tsa"] = "geen-token"; notes.append("tsa: geen token (offline/test-tijdstempel)")

        # 7. gekwalificeerde tijdstempel (27/09/2026): batchwortel → Merkle-pad → gekwalificeerde wortel → QTSP-token (eIDAS art. 41-42)
        qd = m.get("qualified") or {}; q_uit = {}
        if qd.get("root"):
            pad_ok = qd.get("batch_root") == mk.get("root") and merkle_verify(mk["root"], qd.get("path") or [], qd["root"])
            if not pad_ok:
                checks["qualified_tsa"] = False; notes.append("gekwalificeerd: het pad van de batchwortel naar de gekwalificeerde wortel wijkt af")
                afwijking["qualified_tsa"] = "het pad naar de gekwalificeerde wortel hoort niet bij dit stempel"
            elif qd.get("token_b64"):
                checks["qualified_tsa"] = _token_geldig(qd["token_b64"], qd["root"], "gekwalificeerd", notes, ANKERS_GEKWALIFICEERD, uit=q_uit)
                if checks["qualified_tsa"] is True: _tijd_klopt(qd.get("time"), q_uit["moment"], "gekwalificeerd", notes)
                elif checks["qualified_tsa"] is None: redenen["qualified_tsa"] = q_uit.get("reden") or "geen-anker"
                else: afwijking["qualified_tsa"] = _laatste(notes, "gekwalificeerd: ") or "het token hoort niet bij deze wortel"
            else:
                checks["qualified_tsa"] = None; redenen["qualified_tsa"] = "token-ontbreekt"
                notes.append("gekwalificeerd: pad stemt overeen, token niet meegeleverd")

    # 05/10/2026: tekenen gebeurt vóór verankeren (een getekende registratie kan niet opnieuw getekend worden). Het certificaat moet
    # dus bestaan op het moment dat de getuige (nagerekend tijdstempel) de wortel zag, en het tekenmoment ligt daarvóór.
    if checks["signature"] is True and tsa_uit.get("moment") and teken_cert:
        from datetime import timedelta
        from cryptography import x509 as _x
        g = tsa_uit["moment"]; marge = timedelta(minutes=5)
        c = _x.load_pem_x509_certificate(teken_cert.encode())
        voor = getattr(c, "not_valid_before_utc", None) or c.not_valid_before.replace(tzinfo=timezone.utc)
        tm = _iso(teken_moment)
        if voor > g + marge:
            checks["signature"] = False; notes.append(f"signer: het certificaat van de indiener bestond pas vanaf {voor.isoformat()}, ná de getuige ({g.isoformat()})")
            afwijking["signature"] = "het certificaat bestond pas ná het tijdstempel"
        elif tm and tm > g + marge:
            checks["signature"] = False; notes.append(f"signer: volgens het manifest getekend op {teken_moment}, ná de getuige ({g.isoformat()}) — onmogelijk")
            afwijking["signature"] = "volgens het manifest getekend ná het tijdstempel"
    btc = m.get("bitcoin")
    if btc:
        if btc.get("status") == "bitcoin" and btc.get("block_height"):
            # 15/09: het .ots-bewijs zelf narekenen (niet alleen het manifest geloven): het pad van de wortel naar het Bitcoin-blok,
            # en — als er verbinding is — de merkle-wortel van dat blok vergelijken met een publieke explorer (blockstream.info).
            if "bitcoin.ots" not in names:
                checks["bitcoin"] = None; redenen["bitcoin"] = "bewijs-ontbreekt"; notes.append("bitcoin: blokhoogte in manifest, maar bitcoin.ots ontbreekt in de bundel")
            else:
                uit = _bitcoin_bewijs(ots_bytes, mk.get("root"), int(btc.get("block_height")))
                checks["bitcoin"] = uit[0]; notes.append("bitcoin: " + uit[1])
                if uit[0] is None: redenen["bitcoin"] = (uit[2] if len(uit) > 2 else None) or "offline"
                elif uit[0] is False: afwijking["bitcoin"] = uit[1]
        else:
            checks["bitcoin"] = None; redenen["bitcoin"] = "wacht-op-blok"
            notes.append("bitcoin: ingediend bij OpenTimestamps, wacht op bevestiging in een Bitcoin-blok (meestal 1–6 u); bundel later opnieuw downloaden voor het volledige bewijs")
    fab = m.get("fabric")
    if fab and fab.get("tx_id"):
        checks["fabric"] = None; redenen["fabric"] = "buiten-de-bundel"   # feit uit het manifest; live-controle tegen een peer gebeurt door de verificatiepagina of door de deskundige zelf
        notes.append(f"fabric: wortel als transactie {fab['tx_id'][:16]}… op kanaal {fab.get('channel')} (blok {fab.get('block')}); controleer tegen een peer, zie manifest.fabric.how_to_verify")
    co = m.get("co_signatures") or []
    if co:
        goed = []
        for c in co:
            try: goed.append(_ed_verify(c["public_key_pem"], bytes.fromhex(reg["hash"]), base64.b64decode(c["signature_b64"])))
            except Exception: goed.append(False)
        checks["counter_signature"] = all(goed)   # alleen aanwezig als er samen getekend is
        if not all(goed):
            notes.append("tegenhandtekening: minstens één handtekening past niet bij de meegeleverde sleutel")
            afwijking["counter_signature"] = "minstens één handtekening van de tegenpartij past niet bij de meegeleverde sleutel"
    hard = [checks["merkle"], checks["signature"], checks["platform_signature"]]
    integriteit = all(v is True for v in hard) and not any(v is False for v in checks.values())
    ca_vinger = _ca_vingerafdruk(org_ca_pem) if org_ca_pem else None
    # de naam van een vastgepind anker gaat voor op "door de aanroeper vertrouwd" (de server geeft zijn eigen, ook gepubliceerde, CA's mee)
    vertrouwd = {**{str(v).lower().replace(":", ""): "door de aanroeper vertrouwd" for v in vertrouwde_ca}, **VIDIMUS_CA_SHA256}
    platformen = {**{str(v).lower().replace(":", ""): "door de aanroeper vertrouwd" for v in vertrouwd_platform}, **VIDIMUS_PLATFORM_SHA256}
    herkomst = {"ca_sha256": ca_vinger, "ca": vertrouwd.get(ca_vinger) if ca_vinger else None,
                "platform_sha256": platform_vinger, "platform": platformen.get(platform_vinger) if platform_vinger else None}
    herkomst["vertrouwd"] = bool(herkomst["ca"] and herkomst["platform"])
    getuigen = [k for k in ("tsa", "qualified_tsa", "bitcoin") if checks.get(k) is True]
    waarom = []
    if not integriteit:
        status = "NIET GELDIG"
        waarom.append("minstens één controle wijkt af: " + ", ".join(k for k, v in checks.items() if v is False or (k in ("merkle", "signature", "platform_signature") and v is not True)))
    else:
        if not herkomst["ca"]:
            waarom.append(f"de CA in deze bundel (SHA-256 {ca_vinger or 'ontbreekt'}) is niet de gepubliceerde Vidimus-CA — "
                          "de handtekeningen stemmen alleen binnen de bundel overeen, wie tekende is niet onafhankelijk vastgesteld")
        elif not herkomst["platform"]:
            waarom.append(f"het platformcertificaat (SHA-256 {platform_vinger or 'ontbreekt'}) is niet het gepubliceerde platformcertificaat van "
                          "Vidimus — niet vastgesteld dat Vidimus het manifest ondertekende")
        if not getuigen:
            waarom.append("geen externe tijdsgetuige nagerekend (RFC 3161-tijdstempel met keten naar een vastgepind anker, of een "
                          "Bitcoin-blok vergeleken met een publieke explorer) — tijd niet onafhankelijk vastgesteld")
        status = "GELDIG" if not waarom else "ONVOLLEDIG"
    ok = status == "GELDIG"
    reg = m["registration"]; sg = m.get("signer") or {}; mk = m.get("merkle") or {}; ts = m.get("tsa") or {}; lg = m.get("ledger") or {}
    # publiek-veilige details per controle (geen inhoud, geen salt, geen sleutels)
    details = {
        "hash": {"type": reg.get("hash_type"), "value": reg.get("hash"), "attachments": len(reg.get("attachments") or {}), "canon": m.get("canon"),
                 "org": reg.get("org_kenmerk"), "shredded": bool(reg.get("shredded")), **({"gewist_op": gewist_op} if gewist_op else {})},
        "merkle": {"root": mk.get("root"), "batch": mk.get("batch"), "count": mk.get("count"), "path_len": len(mk.get("path") or []), "convention": m.get("merkle_convention")},
        "signature": {"algorithm": "Ed25519", "subject_cn": sg.get("subject_cn"), "subject_org": sg.get("subject_org"), "issuer_cn": sg.get("issuer_cn"),
                      "serial": sg.get("serial"), "key_custody": sg.get("key_custody"), "not_before": sg.get("not_before"), "not_after": sg.get("not_after"),
                      "bevestiging": _bevestiging_tekst(sg.get("bevestiging"))},
        "mandaat": sg.get("mandaat"),
        "platform_signature": {"algorithm": "Ed25519", "signed": "manifest.json (exacte bytes)", "platform": (m.get("platform") or {}).get("name"), "operator": (m.get("platform") or {}).get("operator")},
        "ledger": {"name": lg.get("name"), "channel": lg.get("channel"), "index": lg.get("index"), "tx_id": lg.get("tx_id"),
                   "prev": ((lg.get("record") or {}).get("prev")), "time": ((lg.get("record") or {}).get("time"))},
        "counter_signature": {"count": len(m.get("co_signatures") or []), "names": ", ".join(c.get("naam") or "?" for c in (m.get("co_signatures") or [])) or None,
                              "orgs": ", ".join(c.get("org") or "" for c in (m.get("co_signatures") or []) if c.get("org")) or None,
                              "times": ", ".join((c.get("time") or "")[:19] for c in (m.get("co_signatures") or [])) or None,
                              "via": ", ".join(c.get("via") or "" for c in (m.get("co_signatures") or [])) or None},
        "tsa": {"provider": ts.get("provider"), "url": ts.get("url"), "time": tsa_uit["moment"].isoformat() if tsa_uit.get("moment") else ts.get("time"),
                "time_bron": "token (nagerekend)" if tsa_uit.get("moment") else "manifest (niet nagerekend)", "serial": _tst_serial(ts.get("token_b64")) or None,
                "cert_serial": ts.get("cert_serial") or (ts.get("serial") if (ts.get("serial") or "").upper() != _tst_serial(ts.get("token_b64")) else None), "tier": ts.get("tier", "standard"), "standard": "RFC 3161"},
    }
    og = m.get("organisatie") or {}
    if og:
        details["signature"]["organisatie"] = og.get("naam"); details["signature"]["organisatie_identiteit"] = og.get("identiteit")
        if og.get("mandaat_eid"): details["signature"]["mandaat_eid"] = (og["mandaat_eid"] or {}).get("registratie"); details["signature"]["mandaat_eid_moment"] = (og["mandaat_eid"] or {}).get("moment")
    md = sg.get("mandaat") or {}
    if md:
        details["signature"].update({"mandaat_werkgever": (md.get("werkgever") or {}).get("registratie"), "mandaat_werkgever_moment": (md.get("werkgever") or {}).get("moment"),
                                     "toestelakkoord": (md.get("toestelakkoord") or {}).get("registratie"), "toestelakkoord_moment": (md.get("toestelakkoord") or {}).get("moment"),
                                     "verklaring_persoon": "ja" if md.get("met_verklaring_persoon") else "nee"})
    if fab and fab.get("tx_id"):
        details["fabric"] = {"network": fab.get("network"), "channel": fab.get("channel"), "chaincode": fab.get("chaincode"), "msp": fab.get("msp"), "tx_id": fab.get("tx_id"),
                             "block": fab.get("block"), "submitted": fab.get("submitted"), "key": fab.get("key"), "root": mk.get("root"), "how_to_verify": fab.get("how_to_verify")}
    qd = m.get("qualified") or {}
    if qd.get("root"):
        details["qualified_tsa"] = {"provider": qd.get("provider"), "time": q_uit["moment"].isoformat() if q_uit.get("moment") else qd.get("time"), "serial": _tst_serial(qd.get("token_b64")) or qd.get("serial"),
                                    "tier": "qualified", "standard": "eIDAS art. 42 · RFC 3161", "root": qd.get("root"), "batches": qd.get("batches"), "registraties": qd.get("registraties"),
                                    "path_len": len(qd.get("path") or []), "file": qd.get("file"), "how_to_verify": qd.get("how_to_verify")}
    if btc:
        details["bitcoin"] = {"network": "Bitcoin", "protocol": "OpenTimestamps", "status": "bevestigd" if checks.get("bitcoin") else ("niet vastgesteld" if checks.get("bitcoin") is False else ("in blok, hier niet nagerekend" if btc.get("block_height") else "wacht op blok")), "block_height": btc.get("block_height"),
                              "submitted": btc.get("submitted"), "confirmed": btc.get("confirmed"), "root": mk.get("root"), "file": btc.get("file"), "how_to_verify": btc.get("how_to_verify")}
    for k, v in checks.items():   # elke null draagt een reden; elke false een zin
        if v is None and k not in redenen: redenen[k] = "geen-anker" if k in _GETUIGEN else "geen-inhoud"
        if v is False and k not in afwijking: afwijking[k] = _laatste(notes, k + ": ") or "wijkt af"
    redenen = {k: r for k, r in redenen.items() if checks.get(k) is None}
    afwijking = {k: a for k, a in afwijking.items() if checks.get(k) is False}
    return {"ok": ok, "status": status, "kop": kop_bewijs(checks, herkomst), "redenen": redenen, "afwijking": afwijking,
            "integriteit": integriteit, "waarom": waarom, "herkomst": herkomst, "getuigen": getuigen,
            "checks": checks, "notes": notes, "registration_id": reg["id"],
            "anchored_at": tsa_uit["moment"].isoformat() if tsa_uit.get("moment") else ts.get("time"), "signer": sg.get("subject_cn"),
            "root": mk.get("root"), "tx_id": lg.get("tx_id"), "details": details, "created": reg.get("created"),
            "stream": {"name": (m.get("stream") or {}).get("name"), "sector": (m.get("stream") or {}).get("sector")}}


def ontsleutel_bundel(path, herstel_path, wachtzin: str, naar) -> dict:
    """Laag B (28/09/2026): bijlagen van een vertrouwelijke stroom ontsleutelen met het herstelbestand en de wachtzin van het bedrijf.
    Geeft {bijlage: vingerafdruk klopt}. De originelen komen in de map 'naar'. Alles lokaal; geen netwerk, geen Vidimus."""
    from pathlib import Path
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import padding
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    h = json.loads(Path(herstel_path).read_text())
    if h.get("vidimus") != "herstelsleutel": raise ValueError("dit is geen herstelbestand van Vidimus")
    kdf = h["kdf"]; ver = h["versleuteld"]
    sleutel = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=base64.b64decode(kdf["zout"]), iterations=int(kdf["iteraties"])).derive(wachtzin.encode())
    try: pkcs8 = AESGCM(sleutel).decrypt(base64.b64decode(ver["iv"]), base64.b64decode(ver["data"]), None)
    except Exception: raise ValueError("de wachtzin past niet bij dit herstelbestand")
    priv = serialization.load_der_private_key(pkcs8, password=None)
    oaep = padding.OAEP(mgf=padding.MGF1(hashes.SHA256()), algorithm=hashes.SHA256(), label=None)
    naar = Path(naar); naar.mkdir(parents=True, exist_ok=True); uit = {}
    with zipfile.ZipFile(path) as z:
        m = json.loads(z.read("manifest.json")); sl = json.loads(z.read("sleutels.json")) if "sleutels.json" in z.namelist() else {}
        verwacht = (m.get("registration") or {}).get("attachments") or {}
        for naam, s in sl.items():
            dek = priv.decrypt(base64.b64decode(s["sleutel"]), oaep)
            data = AESGCM(dek).decrypt(base64.b64decode(s["iv"]), z.read(f"attachments/{naam}"), None)
            (naar / Path(naam).name).write_bytes(data)
            uit[naam] = hashlib.sha256(data).hexdigest() == verwacht.get(naam)
    return uit


def _naam(k: str, details: dict) -> str:
    dienst = ((details or {}).get(k) or {}).get("provider") if k in ("tsa", "qualified_tsa") else None
    return _NAMEN.get(k, k) + (f" van {dienst}" if dienst else "")


def cli_regels(res: dict) -> list:
    """De leesbare uitvoer na het JSON-blok (studie §5.1): per controle het woord, dan de uitkomst met de telling, dan de
    technische status. Woorden uit _WOORDEN, nooit 'klopt' of 'geldig'."""
    w = _WOORDEN["uitkomst"]; det = res.get("details") or {}
    btc_blok = (det.get("bitcoin") or {}).get("block_height")
    regels = ["", "PER CONTROLE"]
    for k, v in res["checks"].items():
        naam = _naam(k, det)
        if v is True:
            regels.append(f"  {w['stemt-overeen']:<17} {naam}")
        elif v is False:
            regels.append(f"  {w['wijkt-af']:<17} " + (res["afwijking"].get(k) if k == "hash" and res["afwijking"].get(k) else f"{naam} · {res['afwijking'].get(k, '')}".rstrip(" ·")))
        elif k == "bitcoin" and not btc_blok:
            regels.append(f"  {w['volgt']:<17} {naam} · {_WOORDEN['termijnen']['bitcoin']}")
        else:
            regels.append(f"  {w['niet-nagerekend']:<17} {naam} · {reden_tekst(k, res['redenen'].get(k, ''))}")
    hk = res["herkomst"]
    regels.append("")
    regels.append(f"HERKOMST: CA {hk['ca_sha256'] or '—'} → {hk['ca'] or 'niet de gepubliceerde Vidimus-CA'}")
    regels.append("TIJDSGETUIGEN: " + (", ".join(_naam(k, det) for k in res["getuigen"]) or "geen nagerekend"))
    regels.append("")
    regels.append(f"UITKOMST: {res['kop']['woord']} · {_telling_tekst(telling(res['checks'], det))}")
    for zin in res["waarom"]:
        regels.append("  – " + zin)
    regels.append(f"(technisch: status {res['status']}, afsluitcode {AFSLUITCODE.get(res['status'], 3)})")
    return regels


AFSLUITCODE = {"GELDIG": 0, "NIET GELDIG": 1, "ONVOLLEDIG": 3}


if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[2] == "--herstel":
        import getpass, os
        naar = sys.argv[sys.argv.index("--naar") + 1] if "--naar" in sys.argv else "ontsleuteld"
        zin = os.environ.get("VIDIMUS_WACHTZIN") or getpass.getpass("Wachtzin van het herstelbestand: ")
        uit = ontsleutel_bundel(sys.argv[1], sys.argv[3], zin, naar)
        for naam, ok in uit.items():
            print(f"  {'stemt overeen' if ok else 'wijkt af':<14} {naam}: {'het origineel heeft exact de verankerde vingerafdruk' if ok else 'de vingerafdruk verschilt van de verankerde'}")
        print(f"\nOntsleutelde bestanden in: {naar}")
        sys.exit(0 if uit and all(uit.values()) else 1)
    if len(sys.argv) != 2:
        print(__doc__); sys.exit(2)
    res = verify_bundle(sys.argv[1])
    print(json.dumps(res, indent=2, ensure_ascii=False))
    print("\n".join(cli_regels(res)))
    sys.exit(AFSLUITCODE.get(res["status"], 3))
